export const featuredProducts = [
  {
    id: 1,
    name: "Cotton Blend Sweater",
    category: "Women's Fashion",
    price: 89.99,
    salePrice: 69.99,
    image: "https://images.pexels.com/photos/6214471/pexels-photo-6214471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "A comfortable and stylish cotton blend sweater, perfect for casual outings. Features a relaxed fit and ribbed cuffs.",
    rating: 4.5,
    reviews: 28,
    colors: ["Cream", "Black", "Navy"],
    sizes: ["XS", "S", "M", "L", "XL"]
  },
  {
    id: 2,
    name: "Slim Fit Denim Jeans",
    category: "Men's Fashion",
    price: 79.99,
    image: "https://images.pexels.com/photos/4394351/pexels-photo-4394351.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "Classic slim fit denim jeans with a modern cut. Made from premium cotton with a touch of stretch for comfort.",
    rating: 4.7,
    reviews: 42,
    colors: ["Blue", "Black", "Grey"],
    sizes: ["30", "32", "34", "36", "38"]
  },
  {
    id: 3,
    name: "Leather Crossbody Bag",
    category: "Accessories",
    price: 129.99,
    salePrice: 99.99,
    image: "https://images.pexels.com/photos/5119409/pexels-photo-5119409.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "Elegant leather crossbody bag with adjustable strap and multiple compartments. Perfect for everyday use.",
    rating: 4.8,
    reviews: 56,
    colors: ["Tan", "Black", "Brown"],
    sizes: []
  },
  {
    id: 4,
    name: "Wool Blend Overcoat",
    category: "Men's Fashion",
    price: 199.99,
    image: "https://images.pexels.com/photos/7679453/pexels-photo-7679453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "Sophisticated wool blend overcoat with a classic cut. Features a notched lapel collar and button closure.",
    rating: 4.6,
    reviews: 19,
    colors: ["Charcoal", "Navy", "Camel"],
    sizes: ["S", "M", "L", "XL"]
  }
];

export const allProducts = [
  ...featuredProducts,
  {
    id: 5,
    name: "Floral Print Dress",
    category: "Women's Fashion",
    price: 119.99,
    salePrice: null,
    image: "https://images.pexels.com/photos/7675855/pexels-photo-7675855.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "Beautiful floral print dress with a flattering silhouette. Made from lightweight fabric, perfect for spring and summer.",
    rating: 4.3,
    reviews: 37,
    colors: ["Multicolor"],
    sizes: ["XS", "S", "M", "L"]
  },
  {
    id: 6,
    name: "Leather Derby Shoes",
    category: "Men's Fashion",
    price: 149.99,
    salePrice: null,
    image: "https://images.pexels.com/photos/6540927/pexels-photo-6540927.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "Classic leather derby shoes crafted from premium leather. Features a durable rubber sole and comfortable cushioned insole.",
    rating: 4.8,
    reviews: 64,
    colors: ["Brown", "Black"],
    sizes: ["40", "41", "42", "43", "44", "45"]
  },
  {
    id: 7,
    name: "Stainless Steel Watch",
    category: "Accessories",
    price: 229.99,
    salePrice: 189.99,
    image: "https://images.pexels.com/photos/9979845/pexels-photo-9979845.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "Elegant stainless steel watch with a minimalist design. Features a quartz movement and water-resistant up to 30 meters.",
    rating: 4.9,
    reviews: 83,
    colors: ["Silver", "Gold", "Rose Gold"],
    sizes: []
  },
  {
    id: 8,
    name: "Linen Blend Shirt",
    category: "Men's Fashion",
    price: 69.99,
    salePrice: null,
    image: "https://images.pexels.com/photos/1036627/pexels-photo-1036627.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    description: "Breathable linen blend shirt, perfect for warm weather. Features a relaxed fit and button-up front.",
    rating: 4.4,
    reviews: 29,
    colors: ["White", "Light Blue", "Beige"],
    sizes: ["S", "M", "L", "XL", "XXL"]
  }
];