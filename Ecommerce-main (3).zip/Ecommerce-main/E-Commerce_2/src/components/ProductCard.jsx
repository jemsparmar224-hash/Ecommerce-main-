import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingCart, Heart, Eye } from 'lucide-react';
import { useCart } from '../contexts/CartContext.jsx';

function ProductCard({ product }) {
  const [isHovered, setIsHovered] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const { addToCart } = useCart();

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };

  const handleToggleWishlist = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsWishlisted(!isWishlisted);
  };

  return (
    <div 
      className="group product-card"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative overflow-hidden rounded-lg">
        {/* Product Image */}
        <Link to={`/products/${product.id}`}>
          <div className="aspect-[3/4] overflow-hidden bg-neutral-100">
            <img 
              src={product.image} 
              alt={product.name} 
              className="product-card-img"
            />
          </div>
        </Link>
        
        {/* Quick Actions */}
        <div className="absolute inset-0 flex flex-col justify-between p-3 opacity-0 group-hover:opacity-100 transition-opacity">
          {/* Wishlist Button */}
          <div className="self-end">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleToggleWishlist}
              className={`w-9 h-9 rounded-full flex items-center justify-center ${isWishlisted ? 'bg-accent-500 text-white' : 'bg-white text-neutral-700 hover:text-accent-500'} shadow-md`}
              aria-label={isWishlisted ? "Remove from wishlist" : "Add to wishlist"}
            >
              <Heart className="w-5 h-5" fill={isWishlisted ? "currentColor" : "none"} />
            </motion.button>
          </div>
          
          {/* Quick View and Add to Cart Buttons */}
          <div className="flex items-center justify-center space-x-2 mt-2">
            <Link 
              to={`/products/${product.id}`}
              className="w-9 h-9 rounded-full bg-white text-neutral-700 hover:text-primary-600 shadow-md flex items-center justify-center"
              aria-label="Quick view"
            >
              <Eye className="w-5 h-5" />
            </Link>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={handleAddToCart}
              className="w-9 h-9 rounded-full bg-primary-600 text-white hover:bg-primary-700 shadow-md flex items-center justify-center"
              aria-label="Add to cart"
            >
              <ShoppingCart className="w-5 h-5" />
            </motion.button>
          </div>
        </div>
        
        {/* Sale Badge */}
        {product.salePrice && (
          <div className="absolute top-2 left-2 bg-accent-500 text-white text-xs font-medium px-2 py-1 rounded">
            Sale
          </div>
        )}
      </div>
      
      {/* Product Info */}
      <div className="mt-4 px-1">
        <Link to={`/products/${product.id}`} className="block">
          <h3 className="text-sm text-neutral-500 mb-1">{product.category}</h3>
          <h2 className="font-medium mb-1 hover:text-primary-600 transition-colors">{product.name}</h2>
          
          <div className="flex items-center mt-1">
            {product.salePrice ? (
              <>
                <span className="text-accent-600 font-medium">${product.salePrice.toFixed(2)}</span>
                <span className="text-neutral-500 line-through ml-2 text-sm">${product.price.toFixed(2)}</span>
              </>
            ) : (
              <span className="font-medium">${product.price.toFixed(2)}</span>
            )}
          </div>
        </Link>
      </div>
    </div>
  );
}

export default ProductCard;