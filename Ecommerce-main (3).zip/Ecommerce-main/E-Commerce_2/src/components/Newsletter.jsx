import { useState } from 'react';
import { motion } from 'framer-motion';
import { Send } from 'lucide-react';

function Newsletter() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!email.trim()) {
      setError('Please enter your email address');
      return;
    }
    
    // Simple email validation
    const isValidEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!isValidEmail) {
      setError('Please enter a valid email address');
      return;
    }
    
    // Clear error and simulate success
    setError('');
    setSubmitted(true);
    
    // In a real app, this would call an API to save the email
  };

  return (
    <section className="bg-primary-50 py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-3xl md:text-4xl font-medium text-neutral-900 mb-4"
          >
            Join Our Newsletter
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-neutral-600 mb-8 text-lg max-w-2xl mx-auto"
          >
            Subscribe to get special offers, free giveaways, and exclusive deals.
          </motion.p>
          
          {submitted ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white p-6 rounded-lg shadow-sm max-w-md mx-auto"
            >
              <h3 className="text-xl font-medium text-primary-600 mb-2">Thank You!</h3>
              <p className="text-neutral-600">
                You've been successfully subscribed to our newsletter.
              </p>
            </motion.div>
          ) : (
            <motion.form
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            >
              <div className="flex-1">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  className={`w-full p-3 rounded-md border ${error ? 'border-red-500' : 'border-neutral-300'} focus:outline-none focus:ring-2 focus:ring-primary-500`}
                  aria-label="Email address"
                />
                {error && <p className="mt-1 text-left text-red-500 text-sm">{error}</p>}
              </div>
              <button
                type="submit"
                className="btn btn-primary py-3"
              >
                Subscribe
                <Send className="ml-2 w-4 h-4" />
              </button>
            </motion.form>
          )}
        </div>
      </div>
    </section>
  );
}

export default Newsletter;