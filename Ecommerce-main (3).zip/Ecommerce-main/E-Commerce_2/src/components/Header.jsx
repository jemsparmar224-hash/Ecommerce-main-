import { useState, useEffect } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, User, Search, Menu, X, Heart, ShoppingCart } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.jsx';
import { useCart } from '../contexts/CartContext.jsx';
import Logo from '../assets/Logo.png';

function Header({ isScrolled }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const { currentUser, logout } = useAuth();
  const { totalItems } = useCart();

  // Close mobile menu on navigation or window resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768 && isMenuOpen) {
        setIsMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [isMenuOpen]);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  return (
    <header className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${isScrolled ? 'bg-white shadow-sm' : 'bg-transparent'}`}>
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-xl font-semibold tracking-tight"><img src={Logo} alt="Logo" className="w-28 h-8 mr-2" /></span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLink 
              to="/" 
              className={({ isActive }) => 
                `text-sm font-medium transition-colors hover:text-primary-600 ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
              }
            >
              Home
            </NavLink>
            <NavLink 
              to="/products" 
              className={({ isActive }) => 
                `text-sm font-medium transition-colors hover:text-primary-600 ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
              }
            >
              Shop
            </NavLink>
            <NavLink 
              to="/categories" 
              className={({ isActive }) => 
                `text-sm font-medium transition-colors hover:text-primary-600 ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
              }
            >
              Categories
            </NavLink>
            <NavLink 
              to="/about" 
              className={({ isActive }) => 
                `text-sm font-medium transition-colors hover:text-primary-600 ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
              }
            >
              About
            </NavLink>
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* Search Toggle */}
            <button 
              onClick={() => setSearchOpen(true)}
              className="p-1.5 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors"
              aria-label="Search"
            >
              <Search className="w-5 h-5" />
            </button>
            
            {/* Wishlist - Desktop Only */}
            <Link 
              to="/wishlist" 
              className="hidden sm:flex p-1.5 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
            </Link>
            
            {/* Account */}
            <div className="relative">
              {currentUser ? (
                <Link 
                  to="/dashboard" 
                  className="p-1.5 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors"
                  aria-label="Account"
                >
                  <User className="w-5 h-5" />
                </Link>
              ) : (
                <Link 
                  to="/login" 
                  className="p-1.5 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors"
                  aria-label="Sign in"
                >
                  <User className="w-5 h-5" />
                </Link>
              )}
            </div>
            
            {/* Cart */}
            <Link 
              to="/cart" 
              className="p-1.5 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors relative"
              aria-label="Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 flex items-center justify-center w-5 h-5 text-xs font-medium text-white bg-primary-600 rounded-full">
                  {totalItems}
                </span>
              )}
            </Link>
            
            {/* Mobile Menu Toggle */}
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="p-1.5 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors md:hidden"
              aria-label="Open Menu"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3 }}
            className="fixed inset-0 z-50 bg-white md:hidden"
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-4 border-b">
                <span className="text-xl font-semibold"><img src={Logo} alt="Logo" className="w-28 h-8 mr-2" /></span>
                <button 
                  onClick={() => setIsMenuOpen(false)}
                  className="p-1.5 rounded-full text-neutral-700 hover:bg-neutral-100 transition-colors"
                  aria-label="Close Menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <nav className="flex-1 overflow-y-auto py-4">
                <div className="space-y-1 px-4">
                  <NavLink 
                    to="/" 
                    onClick={() => setIsMenuOpen(false)}
                    className={({ isActive }) => 
                      `block py-2.5 text-base font-medium transition-colors ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
                    }
                  >
                    Home
                  </NavLink>
                  <NavLink 
                    to="/products" 
                    onClick={() => setIsMenuOpen(false)}
                    className={({ isActive }) => 
                      `block py-2.5 text-base font-medium transition-colors ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
                    }
                  >
                    Shop
                  </NavLink>
                  <NavLink 
                    to="/categories" 
                    onClick={() => setIsMenuOpen(false)}
                    className={({ isActive }) => 
                      `block py-2.5 text-base font-medium transition-colors ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
                    }
                  >
                    Categories
                  </NavLink>
                  <NavLink 
                    to="/about" 
                    onClick={() => setIsMenuOpen(false)}
                    className={({ isActive }) => 
                      `block py-2.5 text-base font-medium transition-colors ${isActive ? 'text-primary-600' : 'text-neutral-700'}`
                    }
                  >
                    About
                  </NavLink>
                </div>
                
                <div className="border-t mt-4 pt-4 px-4 space-y-4">
                  <div className="space-y-1">
                    <p className="text-sm font-semibold text-neutral-500">Account</p>
                    {currentUser ? (
                      <>
                        <Link 
                          to="/dashboard" 
                          onClick={() => setIsMenuOpen(false)}
                          className="block py-2 text-base font-medium text-neutral-700"
                        >
                          Dashboard
                        </Link>
                        <button 
                          onClick={() => {
                            logout();
                            setIsMenuOpen(false);
                          }}
                          className="block py-2 text-base font-medium text-neutral-700"
                        >
                          Sign Out
                        </button>
                      </>
                    ) : (
                      <>
                        <Link 
                          to="/login" 
                          onClick={() => setIsMenuOpen(false)}
                          className="block py-2 text-base font-medium text-neutral-700"
                        >
                          Sign In
                        </Link>
                        <Link 
                          to="/register" 
                          onClick={() => setIsMenuOpen(false)}
                          className="block py-2 text-base font-medium text-neutral-700"
                        >
                          Register
                        </Link>
                      </>
                    )}
                  </div>
                </div>
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Search Overlay */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-start justify-center pt-20 px-4"
            onClick={() => setSearchOpen(false)}
          >
            <motion.div 
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="w-full max-w-2xl bg-white rounded-lg overflow-hidden shadow-xl"
              onClick={e => e.stopPropagation()}
            >
              <form onSubmit={handleSearch} className="flex items-center p-4">
                <Search className="w-5 h-5 text-neutral-500 mr-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search products..."
                  className="flex-1 bg-transparent outline-none text-lg"
                  autoFocus
                />
                <button 
                  type="button" 
                  onClick={() => setSearchOpen(false)}
                  className="p-1 text-neutral-500 hover:text-neutral-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

export default Header;