import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.jsx';

function Register() {
  const [user, setUser] = useState({
    fullName: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  let name, value;

  const handleChange = (e) => {
    name = e.target.name;
    value = e.target.value;
    setUser({...user, [name]: value});
  };

  const PostData_Submit = async (e) => {
        e.preventDefault();

        const { fullName, email, password, confirmPassword } = user;
  }

  // const handleSubmit = async (e) => {
  //   e.preventDefault();
    
  //   // Reset error state
  //   setError('');
    
  //   // Validate form
  //   if (!formData.fullName.trim() || !formData.email.trim() || !formData.password.trim() || !formData.confirmPassword.trim()) {
  //     setError('Please fill in all fields');
  //     return;
  //   }
    
  //   if (formData.password !== formData.confirmPassword) {
  //     setError('Passwords do not match');
  //     return;
  //   }
    
  //   if (formData.password.length < 6) {
  //     setError('Password must be at least 6 characters long');
  //     return;
  //   }
    
  //   try {
  //     setLoading(true);
      
  //     // MongoDB integration guide would go here
  //     // For now, we'll simulate registration with a timeout
  //     await register({
  //       fullName: formData.fullName,
  //       email: formData.email
  //     });
      
  //     // Redirect to home page after successful registration
  //     navigate('/');
  //   } catch (err) {
  //     setError('Failed to create an account. Please try again.');
  //     setLoading(false);
  //   }
  // };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="flex flex-col md:flex-row w-full max-w-5xl bg-white rounded-xl shadow-lg overflow-hidden">
        {/* Image Section */}
        <div className="md:w-1/2 relative hidden md:block">
          <img 
            src="https://images.pexels.com/photos/5632397/pexels-photo-5632397.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
            alt="Register" 
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-primary-900/40 flex items-center justify-center">
            <div className="text-white text-center p-8">
              <h2 className="text-3xl font-medium mb-4">Join LUXE</h2>
              <p className="text-white/90 max-w-xs mx-auto">
                Create an account to enjoy personalized shopping experiences and exclusive offers.
              </p>
            </div>
          </div>
        </div>
        
        {/* Form Section */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="md:w-1/2 p-8 md:p-12"
        >
          <div className="mb-8 text-center md:text-left">
            <h1 className="text-2xl font-medium mb-2">Create Account</h1>
            <p className="text-neutral-600">
              Already have an account? <Link to="/login" className="text-primary-600 hover:underline">Sign in</Link>
            </p>
          </div>
          
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
              <AlertCircle className="w-5 h-5 text-red-600 mr-3 mt-0.5 flex-shrink-0" />
              <p className="text-red-600">{error}</p>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="fullName" className="block text-sm font-medium text-neutral-700 mb-1">
                Full Name
              </label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                value={user.name}
                onChange={handleInputs}
                placeholder="John Doe"
                className="input"
                disabled={loading}
                required
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-neutral-700 mb-1">
                Email Address
              </label>
              <input
                id="email"
                name="email"
                type="email"
                value={user.email}
                onChange={handleInputs}
                className="input"
                placeholder="your@email.com"
                disabled={loading}
                required
              />
            </div>
            
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-neutral-700 mb-1">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleInputs}
                  className="input pr-10"
                  placeholder="••••••••"
                  disabled={loading}
                  required
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-neutral-500 hover:text-neutral-700"
                  onClick={() => setShowPassword(!showPassword)}
                  tabIndex="-1"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
              <p className="text-xs text-neutral-500 mt-1">
                Password must be at least 6 characters long.
              </p>
            </div>
            
            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-neutral-700 mb-1">
                Confirm Password
              </label>
              <div className="relative">
                <input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  value={formData.confirmPassword}
                  onChange={handleInputs}
                  className="input pr-10"
                  placeholder="••••••••"
                  disabled={loading}
                  required
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center text-neutral-500 hover:text-neutral-700"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  tabIndex="-1"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>
            
            <div className="flex items-start">
              <input
                id="terms"
                name="terms"
                type="checkbox"
                className="h-4 w-4 text-primary-600 rounded border-neutral-300 focus:ring-primary-500 mt-1"
                required
              />
              <label htmlFor="terms" className="ml-2 block text-sm text-neutral-700">
                I agree to the <Link to="/terms" className="text-primary-600 hover:underline">Terms of Service</Link> and <Link to="/privacy" className="text-primary-600 hover:underline">Privacy Policy</Link>
              </label>
            </div>
            
            <button
              type="submit"
              disabled={loading}
              className="w-full btn btn-primary py-2.5"
              onClick={PostData_Submit}
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Creating account...
                </span>
              ) : (
                "Create Account"
              )}
            </button>
          </form>
          
          {/* <div className="mt-8">
            <h3 className="text-sm font-medium text-neutral-700 mb-3">
              MongoDB Integration Guide
            </h3>
            <div className="bg-neutral-50 p-4 rounded-lg">
              <ol className="list-decimal list-inside space-y-2 text-sm text-neutral-700">
                <li>Set up an Express.js server with MongoDB connection</li>
                <li>Create a user schema with fields for name, email, and password</li>
                <li>Implement password hashing using bcrypt</li>
                <li>Create registration endpoint that validates and stores user data</li>
                <li>Generate JWT tokens for authentication</li>
                <li>Create login endpoint that verifies credentials and issues tokens</li>
                <li>Set up protected routes using middleware to validate tokens</li>
                <li>Connect your React frontend to the backend API</li>
              </ol>
            </div>
          </div> */}
        </motion.div>
      </div>
    </div>
  );
}

export default Register;