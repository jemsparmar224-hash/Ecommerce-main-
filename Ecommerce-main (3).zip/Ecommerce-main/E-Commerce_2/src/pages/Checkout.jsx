import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, CreditCard, AlertCircle } from 'lucide-react';
import { useCart } from '../contexts/CartContext.jsx';
import { useAuth } from '../contexts/AuthContext.jsx';

function Checkout() {
  const { cart, totalItems, totalPrice, clearCart } = useCart();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: currentUser?.email || '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'United States',
    cardName: '',
    cardNumber: '',
    expMonth: '',
    expYear: '',
    cvv: ''
  });
  
  const [errors, setErrors] = useState({});
  const [isProcessing, setIsProcessing] = useState(false);
  
  useEffect(() => {
    // Update page title
    document.title = 'Checkout - LUXE';
    
    // If cart is empty, redirect to cart page
    if (cart.length === 0) {
      navigate('/cart');
    }
  }, [cart, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when field is updated
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validate = () => {
    const newErrors = {};
    
    // Required field validation
    const requiredFields = [
      'firstName', 'lastName', 'email', 'address', 
      'city', 'state', 'zipCode', 'country',
      'cardName', 'cardNumber', 'expMonth', 'expYear', 'cvv'
    ];
    
    requiredFields.forEach(field => {
      if (!formData[field].trim()) {
        newErrors[field] = 'This field is required';
      }
    });
    
    // Email validation
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    // Card number validation (simple 16 digit check)
    if (formData.cardNumber && !/^\d{16}$/.test(formData.cardNumber.replace(/\s/g, ''))) {
      newErrors.cardNumber = 'Please enter a valid 16-digit card number';
    }
    
    // CVV validation (3-4 digits)
    if (formData.cvv && !/^\d{3,4}$/.test(formData.cvv)) {
      newErrors.cvv = 'CVV must be 3 or 4 digits';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validate()) {
      // Scroll to the first error
      const firstError = document.querySelector('.text-red-600');
      if (firstError) {
        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
      return;
    }
    
    try {
      setIsProcessing(true);
      
      // Simulate order processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Clear cart and redirect to success page
      clearCart();
      navigate('/checkout/success');
    } catch (error) {
      console.error('Checkout failed:', error);
      setIsProcessing(false);
      // Handle error appropriately
    }
  };

  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link to="/cart" className="inline-flex items-center text-sm text-neutral-600 hover:text-primary-600">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back to Cart
          </Link>
        </div>
        
        <h1 className="text-2xl font-medium mb-8">Checkout</h1>
        
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          {/* Main Content */}
          <div className="lg:col-span-8">
            <form onSubmit={handleSubmit}>
              {/* Shipping Information */}
              <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden mb-6">
                <div className="p-6 border-b border-neutral-200">
                  <h2 className="text-lg font-medium">Shipping Information</h2>
                </div>
                
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-neutral-700 mb-1">
                        First Name *
                      </label>
                      <input
                        type="text"
                        id="firstName"
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleChange}
                        className={`input w-full ${errors.firstName ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      />
                      {errors.firstName && (
                        <p className="mt-1 text-red-600 text-xs">{errors.firstName}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium text-neutral-700 mb-1">
                        Last Name *
                      </label>
                      <input
                        type="text"
                        id="lastName"
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleChange}
                        className={`input w-full ${errors.lastName ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      />
                      {errors.lastName && (
                        <p className="mt-1 text-red-600 text-xs">{errors.lastName}</p>
                      )}
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="email" className="block text-sm font-medium text-neutral-700 mb-1">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`input w-full ${errors.email ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      />
                      {errors.email && (
                        <p className="mt-1 text-red-600 text-xs">{errors.email}</p>
                      )}
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="address" className="block text-sm font-medium text-neutral-700 mb-1">
                        Street Address *
                      </label>
                      <input
                        type="text"
                        id="address"
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        className={`input w-full ${errors.address ? 'border-red-500' : ''}`}
                        placeholder="House number and street name"
                        disabled={isProcessing}
                      />
                      {errors.address && (
                        <p className="mt-1 text-red-600 text-xs">{errors.address}</p>
                      )}
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="address2" className="block text-sm font-medium text-neutral-700 mb-1">
                        Apartment, suite, etc. (optional)
                      </label>
                      <input
                        type="text"
                        id="address2"
                        name="address2"
                        value={formData.address2 || ''}
                        onChange={handleChange}
                        className="input w-full"
                        disabled={isProcessing}
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium text-neutral-700 mb-1">
                        City *
                      </label>
                      <input
                        type="text"
                        id="city"
                        name="city"
                        value={formData.city}
                        onChange={handleChange}
                        className={`input w-full ${errors.city ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      />
                      {errors.city && (
                        <p className="mt-1 text-red-600 text-xs">{errors.city}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="state" className="block text-sm font-medium text-neutral-700 mb-1">
                        State / Province *
                      </label>
                      <input
                        type="text"
                        id="state"
                        name="state"
                        value={formData.state}
                        onChange={handleChange}
                        className={`input w-full ${errors.state ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      />
                      {errors.state && (
                        <p className="mt-1 text-red-600 text-xs">{errors.state}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="zipCode" className="block text-sm font-medium text-neutral-700 mb-1">
                        ZIP / Postal Code *
                      </label>
                      <input
                        type="text"
                        id="zipCode"
                        name="zipCode"
                        value={formData.zipCode}
                        onChange={handleChange}
                        className={`input w-full ${errors.zipCode ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      />
                      {errors.zipCode && (
                        <p className="mt-1 text-red-600 text-xs">{errors.zipCode}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="country" className="block text-sm font-medium text-neutral-700 mb-1">
                        Country *
                      </label>
                      <select
                        id="country"
                        name="country"
                        value={formData.country}
                        onChange={handleChange}
                        className={`input w-full ${errors.country ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      >
                        <option value="United States">United States</option>
                        <option value="Canada">Canada</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="Australia">Australia</option>
                        {/* Add more countries as needed */}
                      </select>
                      {errors.country && (
                        <p className="mt-1 text-red-600 text-xs">{errors.country}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Payment Information */}
              <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden mb-6">
                <div className="p-6 border-b border-neutral-200">
                  <h2 className="text-lg font-medium">Payment Information</h2>
                </div>
                
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label htmlFor="cardName" className="block text-sm font-medium text-neutral-700 mb-1">
                        Name on Card *
                      </label>
                      <input
                        type="text"
                        id="cardName"
                        name="cardName"
                        value={formData.cardName}
                        onChange={handleChange}
                        className={`input w-full ${errors.cardName ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      />
                      {errors.cardName && (
                        <p className="mt-1 text-red-600 text-xs">{errors.cardName}</p>
                      )}
                    </div>
                    
                    <div className="md:col-span-2">
                      <label htmlFor="cardNumber" className="block text-sm font-medium text-neutral-700 mb-1">
                        Card Number *
                      </label>
                      <div className="relative">
                        <input
                          type="text"
                          id="cardNumber"
                          name="cardNumber"
                          value={formData.cardNumber}
                          onChange={handleChange}
                          placeholder="XXXX XXXX XXXX XXXX"
                          className={`input w-full pl-11 ${errors.cardNumber ? 'border-red-500' : ''}`}
                          disabled={isProcessing}
                        />
                        <div className="absolute inset-y-0 left-0 flex items-center pl-3">
                          <CreditCard className="h-5 w-5 text-neutral-400" />
                        </div>
                      </div>
                      {errors.cardNumber && (
                        <p className="mt-1 text-red-600 text-xs">{errors.cardNumber}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="expMonth" className="block text-sm font-medium text-neutral-700 mb-1">
                        Expiration Month *
                      </label>
                      <select
                        id="expMonth"
                        name="expMonth"
                        value={formData.expMonth}
                        onChange={handleChange}
                        className={`input w-full ${errors.expMonth ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      >
                        <option value="">Month</option>
                        {Array.from({ length: 12 }, (_, i) => {
                          const month = i + 1;
                          return (
                            <option key={month} value={month < 10 ? `0${month}` : month}>
                              {month < 10 ? `0${month}` : month}
                            </option>
                          );
                        })}
                      </select>
                      {errors.expMonth && (
                        <p className="mt-1 text-red-600 text-xs">{errors.expMonth}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="expYear" className="block text-sm font-medium text-neutral-700 mb-1">
                        Expiration Year *
                      </label>
                      <select
                        id="expYear"
                        name="expYear"
                        value={formData.expYear}
                        onChange={handleChange}
                        className={`input w-full ${errors.expYear ? 'border-red-500' : ''}`}
                        disabled={isProcessing}
                      >
                        <option value="">Year</option>
                        {Array.from({ length: 10 }, (_, i) => {
                          const year = new Date().getFullYear() + i;
                          return (
                            <option key={year} value={year}>
                              {year}
                            </option>
                          );
                        })}
                      </select>
                      {errors.expYear && (
                        <p className="mt-1 text-red-600 text-xs">{errors.expYear}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="cvv" className="block text-sm font-medium text-neutral-700 mb-1">
                        CVV *
                      </label>
                      <input
                        type="text"
                        id="cvv"
                        name="cvv"
                        value={formData.cvv}
                        onChange={handleChange}
                        className={`input w-full ${errors.cvv ? 'border-red-500' : ''}`}
                        placeholder="123"
                        maxLength={4}
                        disabled={isProcessing}
                      />
                      {errors.cvv && (
                        <p className="mt-1 text-red-600 text-xs">{errors.cvv}</p>
                      )}
                    </div>
                  </div>
                  
                  <div className="mt-4 p-4 bg-neutral-50 rounded-lg border border-neutral-200">
                    <div className="flex items-start">
                      <AlertCircle className="w-5 h-5 text-neutral-500 mr-3 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-neutral-600">
                        This is a demo checkout page. No actual payment will be processed.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
          
          {/* Order Summary */}
          <div className="lg:col-span-4 mt-8 lg:mt-0">
            <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden sticky top-24">
              <div className="p-6 border-b border-neutral-200">
                <h2 className="text-lg font-medium">Order Summary</h2>
              </div>
              
              <div className="p-6">
                <div className="space-y-4">
                  {cart.map(item => (
                    <div key={`${item.id}-${item.selectedSize || ''}-${item.selectedColor || ''}`} className="flex">
                      <div className="w-16 h-16 flex-shrink-0 bg-neutral-100 rounded overflow-hidden">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover object-center" />
                      </div>
                      <div className="ml-4 flex-1">
                        <p className="text-sm font-medium">{item.name}</p>
                        <div className="flex items-center mt-1 text-xs text-neutral-500">
                          {item.selectedColor && <span className="mr-2">Color: {item.selectedColor}</span>}
                          {item.selectedSize && <span>Size: {item.selectedSize}</span>}
                        </div>
                        <div className="flex justify-between mt-2">
                          <span className="text-sm">${(item.salePrice || item.price).toFixed(2)} × {item.quantity}</span>
                          <span className="text-sm font-medium">${((item.salePrice || item.price) * item.quantity).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-6 pt-6 border-t border-neutral-200">
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Subtotal ({totalItems} items)</span>
                      <span className="font-medium">${totalPrice.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Shipping</span>
                      <span className="font-medium">Free</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-600">Tax</span>
                      <span className="font-medium">${(totalPrice * 0.07).toFixed(2)}</span>
                    </div>
                    
                    <div className="pt-3 mt-3 border-t border-neutral-200">
                      <div className="flex justify-between">
                        <span className="font-medium">Total</span>
                        <span className="font-medium">${(totalPrice + (totalPrice * 0.07)).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <button
                  type="submit"
                  onClick={handleSubmit}
                  disabled={isProcessing}
                  className="mt-6 w-full btn btn-primary py-3"
                >
                  {isProcessing ? (
                    <span className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Processing...
                    </span>
                  ) : (
                    'Place Order'
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Checkout;