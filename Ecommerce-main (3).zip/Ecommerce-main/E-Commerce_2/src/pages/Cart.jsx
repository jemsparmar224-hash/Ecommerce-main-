import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '../contexts/CartContext.jsx';

function Cart() {
  const { cart, totalItems, totalPrice, updateQuantity, removeFromCart } = useCart();
  const [isCheckoutDisabled, setIsCheckoutDisabled] = useState(false);
  
  useEffect(() => {
    // Update page title
    document.title = 'Shopping Cart - LUXE';
    
    // Check if checkout should be disabled (e.g., if cart is empty)
    setIsCheckoutDisabled(cart.length === 0);
  }, [cart]);

  if (cart.length === 0) {
    return (
      <div className="pt-20 min-h-screen">
        <div className="container mx-auto px-4 py-16 text-center">
          <div className="max-w-md mx-auto">
            <div className="w-20 h-20 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <ShoppingBag className="w-10 h-10 text-neutral-400" />
            </div>
            <h1 className="text-2xl font-medium mb-4">Your cart is empty</h1>
            <p className="text-neutral-600 mb-8">
              Looks like you haven't added any products to your cart yet.
            </p>
            <Link to="/products" className="btn btn-primary">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-medium mb-8">Your Shopping Cart</h1>
        
        <div className="lg:grid lg:grid-cols-3 lg:gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            {/* Cart Header - Desktop */}
            <div className="hidden md:grid md:grid-cols-12 py-3 border-b">
              <div className="col-span-6">
                <span className="text-sm font-medium">Product</span>
              </div>
              <div className="col-span-2 text-center">
                <span className="text-sm font-medium">Price</span>
              </div>
              <div className="col-span-2 text-center">
                <span className="text-sm font-medium">Quantity</span>
              </div>
              <div className="col-span-2 text-right">
                <span className="text-sm font-medium">Total</span>
              </div>
            </div>
            
            {/* Cart Items */}
            <div className="divide-y">
              {cart.map((item) => (
                <motion.div 
                  key={`${item.id}-${item.selectedSize || ''}-${item.selectedColor || ''}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="py-6 md:grid md:grid-cols-12 md:gap-6"
                >
                  {/* Product Info */}
                  <div className="md:col-span-6 flex">
                    {/* Product Image */}
                    <div className="w-20 h-20 md:w-24 md:h-24 flex-shrink-0 bg-neutral-100 rounded overflow-hidden">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-cover object-center" 
                      />
                    </div>
                    
                    {/* Product Details */}
                    <div className="ml-4 flex flex-col justify-between">
                      <div>
                        <h3 className="text-sm md:text-base font-medium">{item.name}</h3>
                        <p className="text-sm text-neutral-600 mt-1">{item.category}</p>
                        <div className="flex items-center mt-1">
                          {item.selectedColor && (
                            <span className="text-xs text-neutral-600">
                              Color: {item.selectedColor}
                            </span>
                          )}
                          {item.selectedSize && (
                            <span className="text-xs text-neutral-600 ml-3">
                              Size: {item.selectedSize}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      {/* Mobile Price */}
                      <div className="md:hidden mt-2">
                        <span className="text-sm font-medium">
                          ${(item.salePrice || item.price).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {/* Price - Desktop */}
                  <div className="hidden md:flex md:col-span-2 items-center justify-center">
                    <span className="text-sm">${(item.salePrice || item.price).toFixed(2)}</span>
                  </div>
                  
                  {/* Quantity */}
                  <div className="md:col-span-2 flex items-center md:justify-center mt-4 md:mt-0">
                    <div className="flex">
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="w-8 h-8 border border-neutral-300 rounded-l flex items-center justify-center text-neutral-600 hover:bg-neutral-50"
                        aria-label="Decrease quantity"
                      >
                        -
                      </button>
                      <div className="w-10 h-8 border-t border-b border-neutral-300 flex items-center justify-center">
                        {item.quantity}
                      </div>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="w-8 h-8 border border-neutral-300 rounded-r flex items-center justify-center text-neutral-600 hover:bg-neutral-50"
                        aria-label="Increase quantity"
                      >
                        +
                      </button>
                    </div>
                    
                    {/* Mobile Total */}
                    <div className="md:hidden ml-auto">
                      <span className="text-sm font-medium">
                        ${((item.salePrice || item.price) * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  </div>
                  
                  {/* Total - Desktop */}
                  <div className="hidden md:flex md:col-span-2 items-center justify-end">
                    <span className="text-sm font-medium">
                      ${((item.salePrice || item.price) * item.quantity).toFixed(2)}
                    </span>
                  </div>
                  
                  {/* Remove Button */}
                  <div className="mt-4 md:mt-0 flex items-center justify-end">
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="text-neutral-400 hover:text-neutral-600 transition-colors"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
            
            {/* Continue Shopping - Mobile */}
            <div className="mt-8 lg:hidden">
              <Link to="/products" className="inline-flex items-center text-primary-600 text-sm font-medium hover:underline">
                <ShoppingBag className="w-4 h-4 mr-2" />
                Continue Shopping
              </Link>
            </div>
          </div>
          
          {/* Order Summary */}
          <div className="mt-10 lg:mt-0">
            <div className="bg-neutral-50 rounded-lg p-6 sticky top-24">
              <h2 className="text-lg font-medium mb-4">Order Summary</h2>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-600">Subtotal ({totalItems} items)</span>
                  <span className="font-medium">${totalPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Shipping</span>
                  <span className="font-medium">Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-600">Tax</span>
                  <span className="font-medium">${(totalPrice * 0.07).toFixed(2)}</span>
                </div>
                
                <div className="pt-3 mt-3 border-t border-neutral-200">
                  <div className="flex justify-between">
                    <span className="font-medium">Total</span>
                    <span className="font-medium">${(totalPrice + (totalPrice * 0.07)).toFixed(2)}</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <Link
                  to="/checkout"
                  className={`btn btn-primary w-full py-3 ${isCheckoutDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                  aria-disabled={isCheckoutDisabled}
                >
                  Proceed to Checkout
                </Link>
              </div>
              
              {/* Continue Shopping - Desktop */}
              <div className="mt-6 hidden lg:block text-center">
                <Link to="/products" className="inline-flex items-center text-primary-600 text-sm font-medium hover:underline">
                  <ShoppingBag className="w-4 h-4 mr-2" />
                  Continue Shopping
                </Link>
              </div>
              
              {/* Accepted Payment Methods */}
              <div className="mt-6">
                <p className="text-xs text-neutral-500 mb-2 text-center">We accept:</p>
                <div className="flex justify-center space-x-2">
                  {/* Payment Icons would go here (replace with actual icons) */}
                  <div className="w-10 h-6 bg-neutral-200 rounded"></div>
                  <div className="w-10 h-6 bg-neutral-200 rounded"></div>
                  <div className="w-10 h-6 bg-neutral-200 rounded"></div>
                  <div className="w-10 h-6 bg-neutral-200 rounded"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Additional Features - For Larger Screens */}
        <div className="mt-16 hidden md:block">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg border border-neutral-200">
              <h3 className="text-lg font-medium mb-3">Secure Checkout</h3>
              <p className="text-neutral-600 text-sm">
                Your payment information is processed securely. We do not store credit card details.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg border border-neutral-200">
              <h3 className="text-lg font-medium mb-3">Free Shipping</h3>
              <p className="text-neutral-600 text-sm">
                Free standard shipping on all orders over $100. Expedited options available.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg border border-neutral-200">
              <h3 className="text-lg font-medium mb-3">Easy Returns</h3>
              <p className="text-neutral-600 text-sm">
                Not satisfied? Return products within 30 days for a full refund.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Cart;