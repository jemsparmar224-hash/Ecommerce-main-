import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, ShoppingBag } from 'lucide-react';

function NotFound() {
  return (
    <div className="pt-20 min-h-screen flex items-center justify-center">
      <div className="container mx-auto px-4 py-16 text-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-md mx-auto"
        >
          <div className="text-6xl font-bold text-primary-600 mb-6">404</div>
          <h1 className="text-2xl font-medium mb-4">Page Not Found</h1>
          <p className="text-neutral-600 mb-8">
            Oops! The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/" className="btn btn-primary inline-flex items-center justify-center">
              <Home className="w-4 h-4 mr-2" />
              Back to Home
            </Link>
            <Link to="/products" className="btn btn-outline inline-flex items-center justify-center">
              <ShoppingBag className="w-4 h-4 mr-2" />
              Browse Products
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default NotFound;