import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Filter, ChevronDown, X } from 'lucide-react';
import ProductCard from '../components/ProductCard.jsx';
import { allProducts } from '../data/products.jsx';

function Products() {
  const [searchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    category: searchParams.get('category') || 'all',
    price: 'all',
    sort: 'newest'
  });
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  useEffect(() => {
    // Simulate loading products from API
    const timer = setTimeout(() => {
      setProducts(allProducts);
      setLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    // Apply filters
    let result = [...products];
    
    // Filter by category
    if (filters.category !== 'all') {
      result = result.filter(product => 
        product.category.toLowerCase().includes(filters.category.toLowerCase())
      );
    }
    
    // Filter by price
    if (filters.price !== 'all') {
      switch (filters.price) {
        case 'under-50':
          result = result.filter(product => 
            (product.salePrice || product.price) < 50
          );
          break;
        case '50-100':
          result = result.filter(product => {
            const price = product.salePrice || product.price;
            return price >= 50 && price <= 100;
          });
          break;
        case '100-200':
          result = result.filter(product => {
            const price = product.salePrice || product.price;
            return price > 100 && price <= 200;
          });
          break;
        case 'over-200':
          result = result.filter(product => 
            (product.salePrice || product.price) > 200
          );
          break;
        default:
          break;
      }
    }
    
    // Sort products
    switch (filters.sort) {
      case 'price-low-high':
        result.sort((a, b) => 
          (a.salePrice || a.price) - (b.salePrice || b.price)
        );
        break;
      case 'price-high-low':
        result.sort((a, b) => 
          (b.salePrice || b.price) - (a.salePrice || a.price)
        );
        break;
      case 'newest':
        // In a real app, would sort by date
        // For this demo, we'll keep original order which we assume is newest first
        break;
      default:
        break;
    }
    
    setFilteredProducts(result);
  }, [products, filters]);

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
  };

  return (
    <div className="pt-20 min-h-screen">
      {/* Page Header */}
      <div className="bg-neutral-100 py-10">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl font-medium mb-2">Shop All Products</h1>
          <p className="text-neutral-600">
            Discover our collection of quality products designed for you
          </p>
        </div>
      </div>
      
      <div className="container mx-auto px-4 py-8">
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Filters - Desktop */}
          <div className="hidden lg:block space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-4">Categories</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="category-all" 
                    name="category" 
                    value="all" 
                    checked={filters.category === 'all'} 
                    onChange={() => handleFilterChange('category', 'all')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="category-all" className="ml-2 text-sm text-neutral-700">All Categories</label>
                </div>
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="category-women" 
                    name="category" 
                    value="women" 
                    checked={filters.category === 'women'} 
                    onChange={() => handleFilterChange('category', 'women')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="category-women" className="ml-2 text-sm text-neutral-700">Women's Fashion</label>
                </div>
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="category-men" 
                    name="category" 
                    value="men" 
                    checked={filters.category === 'men'} 
                    onChange={() => handleFilterChange('category', 'men')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="category-men" className="ml-2 text-sm text-neutral-700">Men's Fashion</label>
                </div>
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="category-accessories" 
                    name="category" 
                    value="accessories" 
                    checked={filters.category === 'accessories'} 
                    onChange={() => handleFilterChange('category', 'accessories')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="category-accessories" className="ml-2 text-sm text-neutral-700">Accessories</label>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-4">Price</h3>
              <div className="space-y-2">
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="price-all" 
                    name="price" 
                    value="all" 
                    checked={filters.price === 'all'} 
                    onChange={() => handleFilterChange('price', 'all')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="price-all" className="ml-2 text-sm text-neutral-700">All Prices</label>
                </div>
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="price-under-50" 
                    name="price" 
                    value="under-50" 
                    checked={filters.price === 'under-50'} 
                    onChange={() => handleFilterChange('price', 'under-50')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="price-under-50" className="ml-2 text-sm text-neutral-700">Under $50</label>
                </div>
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="price-50-100" 
                    name="price" 
                    value="50-100" 
                    checked={filters.price === '50-100'} 
                    onChange={() => handleFilterChange('price', '50-100')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="price-50-100" className="ml-2 text-sm text-neutral-700">$50 - $100</label>
                </div>
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="price-100-200" 
                    name="price" 
                    value="100-200" 
                    checked={filters.price === '100-200'} 
                    onChange={() => handleFilterChange('price', '100-200')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="price-100-200" className="ml-2 text-sm text-neutral-700">$100 - $200</label>
                </div>
                <div className="flex items-center">
                  <input 
                    type="radio" 
                    id="price-over-200" 
                    name="price" 
                    value="over-200" 
                    checked={filters.price === 'over-200'} 
                    onChange={() => handleFilterChange('price', 'over-200')}
                    className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                  />
                  <label htmlFor="price-over-200" className="ml-2 text-sm text-neutral-700">Over $200</label>
                </div>
              </div>
            </div>
          </div>
          
          {/* Products */}
          <div className="lg:col-span-3">
            {/* Mobile Filter Controls */}
            <div className="lg:hidden mb-6">
              <div className="flex items-center justify-between">
                <button 
                  onClick={() => setMobileFiltersOpen(true)} 
                  className="flex items-center text-sm font-medium text-neutral-700"
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Filters
                </button>
                
                <div className="relative">
                  <select
                    value={filters.sort}
                    onChange={(e) => handleFilterChange('sort', e.target.value)}
                    className="appearance-none bg-white border border-neutral-300 rounded-md py-2 pl-3 pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
                  >
                    <option value="newest">Newest</option>
                    <option value="price-low-high">Price: Low to High</option>
                    <option value="price-high-low">Price: High to Low</option>
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-neutral-500" />
                </div>
              </div>
            </div>
            
            {/* Desktop Sort */}
            <div className="hidden lg:flex justify-between items-center mb-6">
              <p className="text-sm text-neutral-600">
                Showing {filteredProducts.length} products
              </p>
              
              <div className="relative">
                <select
                  value={filters.sort}
                  onChange={(e) => handleFilterChange('sort', e.target.value)}
                  className="appearance-none bg-white border border-neutral-300 rounded-md py-2 pl-3 pr-10 text-sm focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
                >
                  <option value="newest">Sort by: Newest</option>
                  <option value="price-low-high">Sort by: Price: Low to High</option>
                  <option value="price-high-low">Sort by: Price: High to Low</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-neutral-500" />
              </div>
            </div>
            
            {/* Products Grid */}
            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, index) => (
                  <div key={index} className="animate-pulse">
                    <div className="bg-neutral-200 aspect-[3/4] rounded-lg mb-4"></div>
                    <div className="h-4 bg-neutral-200 rounded w-1/4 mb-2"></div>
                    <div className="h-5 bg-neutral-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-neutral-200 rounded w-1/3"></div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <p className="text-lg text-neutral-600 mb-4">No products found matching your criteria.</p>
                <button 
                  onClick={() => setFilters({
                    category: 'all',
                    price: 'all',
                    sort: 'newest'
                  })}
                  className="btn btn-outline"
                >
                  Clear Filters
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Mobile Filters Drawer */}
      {mobileFiltersOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden lg:hidden">
          <div className="absolute inset-0 bg-black bg-opacity-50" onClick={() => setMobileFiltersOpen(false)}></div>
          <div className="absolute inset-y-0 right-0 max-w-xs w-full bg-white flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-lg font-medium">Filters</h2>
              <button onClick={() => setMobileFiltersOpen(false)} className="p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-6">
              <div>
                <h3 className="font-medium mb-4">Categories</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-category-all" 
                      name="mobile-category" 
                      value="all" 
                      checked={filters.category === 'all'} 
                      onChange={() => handleFilterChange('category', 'all')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-category-all" className="ml-2 text-sm text-neutral-700">All Categories</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-category-women" 
                      name="mobile-category" 
                      value="women" 
                      checked={filters.category === 'women'} 
                      onChange={() => handleFilterChange('category', 'women')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-category-women" className="ml-2 text-sm text-neutral-700">Women's Fashion</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-category-men" 
                      name="mobile-category" 
                      value="men" 
                      checked={filters.category === 'men'} 
                      onChange={() => handleFilterChange('category', 'men')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-category-men" className="ml-2 text-sm text-neutral-700">Men's Fashion</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-category-accessories" 
                      name="mobile-category" 
                      value="accessories" 
                      checked={filters.category === 'accessories'} 
                      onChange={() => handleFilterChange('category', 'accessories')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-category-accessories" className="ml-2 text-sm text-neutral-700">Accessories</label>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-4">Price</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-price-all" 
                      name="mobile-price" 
                      value="all" 
                      checked={filters.price === 'all'} 
                      onChange={() => handleFilterChange('price', 'all')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-price-all" className="ml-2 text-sm text-neutral-700">All Prices</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-price-under-50" 
                      name="mobile-price" 
                      value="under-50" 
                      checked={filters.price === 'under-50'} 
                      onChange={() => handleFilterChange('price', 'under-50')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-price-under-50" className="ml-2 text-sm text-neutral-700">Under $50</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-price-50-100" 
                      name="mobile-price" 
                      value="50-100" 
                      checked={filters.price === '50-100'} 
                      onChange={() => handleFilterChange('price', '50-100')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-price-50-100" className="ml-2 text-sm text-neutral-700">$50 - $100</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-price-100-200" 
                      name="mobile-price" 
                      value="100-200" 
                      checked={filters.price === '100-200'} 
                      onChange={() => handleFilterChange('price', '100-200')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-price-100-200" className="ml-2 text-sm text-neutral-700">$100 - $200</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-price-over-200" 
                      name="mobile-price" 
                      value="over-200" 
                      checked={filters.price === 'over-200'} 
                      onChange={() => handleFilterChange('price', 'over-200')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-price-over-200" className="ml-2 text-sm text-neutral-700">Over $200</label>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-medium mb-4">Sort By</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-sort-newest" 
                      name="mobile-sort" 
                      value="newest" 
                      checked={filters.sort === 'newest'} 
                      onChange={() => handleFilterChange('sort', 'newest')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-sort-newest" className="ml-2 text-sm text-neutral-700">Newest</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-sort-price-low" 
                      name="mobile-sort" 
                      value="price-low-high" 
                      checked={filters.sort === 'price-low-high'} 
                      onChange={() => handleFilterChange('sort', 'price-low-high')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-sort-price-low" className="ml-2 text-sm text-neutral-700">Price: Low to High</label>
                  </div>
                  <div className="flex items-center">
                    <input 
                      type="radio" 
                      id="mobile-sort-price-high" 
                      name="mobile-sort" 
                      value="price-high-low" 
                      checked={filters.sort === 'price-high-low'} 
                      onChange={() => handleFilterChange('sort', 'price-high-low')}
                      className="h-4 w-4 text-primary-600 focus:ring-primary-500"
                    />
                    <label htmlFor="mobile-sort-price-high" className="ml-2 text-sm text-neutral-700">Price: High to Low</label>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-4 border-t">
              <button 
                onClick={() => {
                  setFilters({
                    category: 'all',
                    price: 'all',
                    sort: 'newest'
                  });
                }}
                className="btn btn-outline w-full mb-3"
              >
                Clear All
              </button>
              <button 
                onClick={() => setMobileFiltersOpen(false)} 
                className="btn btn-primary w-full"
              >
                Apply Filters
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Products;