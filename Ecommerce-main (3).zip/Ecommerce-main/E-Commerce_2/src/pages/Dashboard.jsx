import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Package, Heart, LogOut, Edit, ShoppingBag } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.jsx';

function Dashboard() {
  const { currentUser, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  
  // Mock orders data
  const [orders, setOrders] = useState([]);
  
  useEffect(() => {
    // Update page title
    document.title = 'My Account - LUXE';
    
    // Simulate fetching orders
    const mockOrders = [
      {
        id: 'ORD-1234',
        date: '2023-11-15',
        status: 'Delivered',
        total: 139.98,
        items: 2
      },
      {
        id: 'ORD-1235',
        date: '2023-12-03',
        status: 'Processing',
        total: 79.99,
        items: 1
      },
    ];
    
    setOrders(mockOrders);
  }, []);

  const handleLogout = () => {
    logout();
  };

  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-medium mb-2">My Account</h1>
        <p className="text-neutral-600 mb-8">
          Welcome back, {currentUser?.fullName || currentUser?.email || 'Customer'}
        </p>
        
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg border border-neutral-200 overflow-hidden sticky top-24">
              <div className="p-6 bg-neutral-50 border-b border-neutral-200">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                    <User className="w-6 h-6 text-primary-600" />
                  </div>
                  <div className="ml-3">
                    <p className="font-medium truncate">
                      {currentUser?.fullName || currentUser?.email || 'Customer'}
                    </p>
                    <p className="text-sm text-neutral-500 truncate">
                      {currentUser?.email || ''}
                    </p>
                  </div>
                </div>
              </div>
              
              <nav className="p-2">
                <button
                  onClick={() => setActiveTab('profile')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-sm ${
                    activeTab === 'profile' 
                      ? 'bg-primary-50 text-primary-600' 
                      : 'text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  <User className="w-5 h-5 mr-3" />
                  Profile
                </button>
                
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-sm ${
                    activeTab === 'orders' 
                      ? 'bg-primary-50 text-primary-600' 
                      : 'text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  <Package className="w-5 h-5 mr-3" />
                  Orders
                </button>
                
                <button
                  onClick={() => setActiveTab('wishlist')}
                  className={`w-full flex items-center px-4 py-2 rounded-md text-sm ${
                    activeTab === 'wishlist' 
                      ? 'bg-primary-50 text-primary-600' 
                      : 'text-neutral-700 hover:bg-neutral-50'
                  }`}
                >
                  <Heart className="w-5 h-5 mr-3" />
                  Wishlist
                </button>
                
                <div className="px-3 pt-2 pb-1 mt-2 border-t border-neutral-200">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center px-4 py-2 rounded-md text-sm text-neutral-700 hover:bg-neutral-50"
                  >
                    <LogOut className="w-5 h-5 mr-3" />
                    Sign Out
                  </button>
                </div>
              </nav>
            </div>
          </div>
          
          {/* Content */}
          <div className="mt-6 lg:mt-0 lg:col-span-3">
            {/* Profile Tab */}
            {activeTab === 'profile' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-lg border border-neutral-200 overflow-hidden"
              >
                <div className="p-6 border-b border-neutral-200 flex justify-between items-center">
                  <h2 className="text-lg font-medium">Personal Information</h2>
                  <button className="text-primary-600 hover:text-primary-700 text-sm flex items-center">
                    <Edit className="w-4 h-4 mr-1" />
                    Edit
                  </button>
                </div>
                
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-sm text-neutral-500 mb-1">Full Name</h3>
                      <p>{currentUser?.fullName || 'Not provided'}</p>
                    </div>
                    <div>
                      <h3 className="text-sm text-neutral-500 mb-1">Email Address</h3>
                      <p>{currentUser?.email || 'Not provided'}</p>
                    </div>
                    <div>
                      <h3 className="text-sm text-neutral-500 mb-1">Phone Number</h3>
                      <p>Not provided</p>
                    </div>
                    <div>
                      <h3 className="text-sm text-neutral-500 mb-1">Date Joined</h3>
                      <p>{new Date(currentUser?.createdAt || Date.now()).toLocaleDateString()}</p>
                    </div>
                  </div>
                </div>
                
                <div className="p-6 border-t border-neutral-200">
                  <h2 className="text-lg font-medium mb-4">Default Address</h2>
                  <p className="text-neutral-600 mb-4">You haven't added any addresses yet.</p>
                  <button className="btn btn-outline text-sm">
                    Add New Address
                  </button>
                </div>
              </motion.div>
            )}
            
            {/* Orders Tab */}
            {activeTab === 'orders' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-lg border border-neutral-200 overflow-hidden"
              >
                <div className="p-6 border-b border-neutral-200">
                  <h2 className="text-lg font-medium">Order History</h2>
                </div>
                
                <div className="overflow-x-auto">
                  {orders.length > 0 ? (
                    <table className="min-w-full divide-y divide-neutral-200">
                      <thead className="bg-neutral-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            Order
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            Date
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            Total
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-neutral-200">
                        {orders.map((order) => (
                          <tr key={order.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-900">
                              {order.id}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              {new Date(order.date).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                order.status === 'Delivered' 
                                  ? 'bg-green-100 text-green-800' 
                                  : 'bg-yellow-100 text-yellow-800'
                              }`}>
                                {order.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              ${order.total.toFixed(2)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-600">
                              <Link to={`/orders/${order.id}`} className="text-primary-600 hover:text-primary-900">
                                View
                              </Link>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="py-12 text-center">
                      <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Package className="w-8 h-8 text-neutral-400" />
                      </div>
                      <h3 className="text-lg font-medium mb-2">No orders yet</h3>
                      <p className="text-neutral-600 mb-6">
                        You haven't placed any orders yet.
                      </p>
                      <Link to="/products" className="btn btn-primary">
                        Browse Products
                      </Link>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
            
            {/* Wishlist Tab */}
            {activeTab === 'wishlist' && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-lg border border-neutral-200 overflow-hidden"
              >
                <div className="p-6 border-b border-neutral-200">
                  <h2 className="text-lg font-medium">My Wishlist</h2>
                </div>
                
                <div className="p-12 text-center">
                  <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="w-8 h-8 text-neutral-400" />
                  </div>
                  <h3 className="text-lg font-medium mb-2">Your wishlist is empty</h3>
                  <p className="text-neutral-600 mb-6">
                    Add items to your wishlist by clicking the heart icon on product pages.
                  </p>
                  <Link to="/products" className="btn btn-primary">
                    Explore Products
                  </Link>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;