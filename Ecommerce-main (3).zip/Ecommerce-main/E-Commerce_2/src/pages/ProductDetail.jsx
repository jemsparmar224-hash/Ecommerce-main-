import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, ShoppingBag, Heart, Share, Star, Truck, Shield, Package } from 'lucide-react';
import { useCart } from '../contexts/CartContext.jsx';
import { allProducts } from '../data/products.jsx';

function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedColor, setSelectedColor] = useState('');
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [isWishlisted, setIsWishlisted] = useState(false);
  
  useEffect(() => {
    // Simulate API call to fetch product
    const timer = setTimeout(() => {
      const foundProduct = allProducts.find(p => p.id === parseInt(id));
      
      if (foundProduct) {
        setProduct(foundProduct);
        if (foundProduct.colors && foundProduct.colors.length > 0) {
          setSelectedColor(foundProduct.colors[0]);
        }
        if (foundProduct.sizes && foundProduct.sizes.length > 0) {
          setSelectedSize(foundProduct.sizes[0]);
        }
        // Update page title
        document.title = `${foundProduct.name} - LUXE`;
      }
      
      setLoading(false);
    }, 800);
    
    return () => clearTimeout(timer);
  }, [id]);

  const handleAddToCart = () => {
    if (!selectedColor && product.colors && product.colors.length > 0) {
      alert('Please select a color');
      return;
    }
    
    if (!selectedSize && product.sizes && product.sizes.length > 0) {
      alert('Please select a size');
      return;
    }
    
    addToCart({
      ...product,
      selectedColor,
      selectedSize
    }, quantity);
    
    // Show success notification or redirect to cart
    navigate('/cart');
  };

  if (loading) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="w-16 h-16 border-4 border-primary-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="pt-20 min-h-screen">
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-medium mb-4">Product Not Found</h1>
          <p className="text-neutral-600 mb-8">The product you are looking for does not exist or has been removed.</p>
          <Link to="/products" className="btn btn-primary">
            Continue Shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link to="/products" className="inline-flex items-center text-sm text-neutral-600 hover:text-primary-600">
            <ChevronLeft className="w-4 h-4 mr-1" />
            Back to Products
          </Link>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Product Images */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="sticky top-24">
              <div className="aspect-[3/4] bg-neutral-100 rounded-lg overflow-hidden mb-4">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover object-center"
                />
              </div>
            </div>
          </motion.div>
          
          {/* Product Info */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex flex-col"
          >
            <span className="text-neutral-600 text-sm mb-1">{product.category}</span>
            <h1 className="text-3xl font-medium mb-2">{product.name}</h1>
            
            {/* Rating */}
            <div className="flex items-center mb-4">
              <div className="flex">
                {[...Array(5)].map((_, index) => (
                  <Star 
                    key={index} 
                    className={`w-4 h-4 ${index < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-neutral-300'}`} 
                  />
                ))}
              </div>
              <span className="ml-2 text-sm text-neutral-600">
                {product.rating} · {product.reviews} reviews
              </span>
            </div>
            
            {/* Price */}
            <div className="mb-6">
              {product.salePrice ? (
                <div className="flex items-center">
                  <span className="text-2xl font-medium text-accent-600">${product.salePrice.toFixed(2)}</span>
                  <span className="ml-3 text-neutral-500 line-through">${product.price.toFixed(2)}</span>
                  <span className="ml-3 bg-accent-50 text-accent-600 text-xs font-medium px-2 py-1 rounded">
                    {Math.round((1 - product.salePrice / product.price) * 100)}% OFF
                  </span>
                </div>
              ) : (
                <span className="text-2xl font-medium">${product.price.toFixed(2)}</span>
              )}
            </div>
            
            {/* Description */}
            <p className="text-neutral-600 mb-8">
              {product.description}
            </p>
            
            {/* Color Selection */}
            {product.colors && product.colors.length > 0 && (
              <div className="mb-6">
                <h3 className="text-sm font-medium mb-3">Color: <span className="font-normal">{selectedColor}</span></h3>
                <div className="flex space-x-3">
                  {product.colors.map(color => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${selectedColor === color ? 'border-primary-600' : 'border-neutral-300'}`}
                      aria-label={`Select ${color} color`}
                    >
                      <span className="w-8 h-8 rounded-full bg-neutral-200"></span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Size Selection */}
            {product.sizes && product.sizes.length > 0 && (
              <div className="mb-6">
                <div className="flex justify-between mb-3">
                  <h3 className="text-sm font-medium">Size: <span className="font-normal">{selectedSize}</span></h3>
                  <button className="text-sm text-primary-600 hover:underline">Size Guide</button>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {product.sizes.map(size => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`py-2 border rounded-md text-sm font-medium transition ${
                        selectedSize === size 
                          ? 'border-primary-600 bg-primary-50 text-primary-600' 
                          : 'border-neutral-300 text-neutral-700 hover:border-neutral-400'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Quantity */}
            <div className="mb-8">
              <h3 className="text-sm font-medium mb-3">Quantity</h3>
              <div className="flex">
                <button 
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-10 h-10 border border-neutral-300 rounded-l-md flex items-center justify-center text-neutral-600 hover:bg-neutral-50"
                  aria-label="Decrease quantity"
                  disabled={quantity <= 1}
                >
                  -
                </button>
                <div className="w-16 h-10 border-t border-b border-neutral-300 flex items-center justify-center">
                  {quantity}
                </div>
                <button 
                  onClick={() => setQuantity(q => q + 1)}
                  className="w-10 h-10 border border-neutral-300 rounded-r-md flex items-center justify-center text-neutral-600 hover:bg-neutral-50"
                  aria-label="Increase quantity"
                >
                  +
                </button>
              </div>
            </div>
            
            {/* Add to Cart/Wishlist */}
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <button
                onClick={handleAddToCart}
                className="btn btn-primary py-3 flex-1 flex items-center justify-center"
              >
                <ShoppingBag className="w-5 h-5 mr-2" />
                Add to Cart
              </button>
              
              <button
                onClick={() => setIsWishlisted(!isWishlisted)}
                className={`btn btn-outline py-3 sm:flex-0 ${isWishlisted ? 'border-accent-600 text-accent-600 hover:bg-accent-50' : ''}`}
              >
                <Heart className="w-5 h-5" fill={isWishlisted ? "currentColor" : "none"} />
              </button>
              
              <button
                className="btn btn-outline py-3 sm:flex-0"
              >
                <Share className="w-5 h-5" />
              </button>
            </div>
            
            {/* Shipping Info */}
            <div className="border-t border-neutral-200 pt-6 mb-6">
              <div className="space-y-4">
                <div className="flex">
                  <Truck className="w-5 h-5 text-neutral-600 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium">Free Shipping</h4>
                    <p className="text-sm text-neutral-600">Free standard shipping on orders over $100</p>
                  </div>
                </div>
                <div className="flex">
                  <Package className="w-5 h-5 text-neutral-600 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium">Easy Returns</h4>
                    <p className="text-sm text-neutral-600">Return within 30 days for a full refund</p>
                  </div>
                </div>
                <div className="flex">
                  <Shield className="w-5 h-5 text-neutral-600 mr-3 flex-shrink-0" />
                  <div>
                    <h4 className="text-sm font-medium">Secure Checkout</h4>
                    <p className="text-sm text-neutral-600">Your payment information is processed securely</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;