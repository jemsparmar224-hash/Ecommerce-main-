import React from 'react';

const variants = {
  primary: 'bg-indigo-100 text-indigo-800',
  secondary: 'bg-slate-100 text-slate-800',
  success: 'bg-emerald-100 text-emerald-800',
  danger: 'bg-red-100 text-red-800',
  warning: 'bg-amber-100 text-amber-800',
};

const sizes = {
  sm: 'text-xs px-2 py-0.5',
  md: 'text-sm px-2.5 py-0.5',
  lg: 'text-base px-3 py-1',
};

const Badge = ({
  children,
  variant = 'primary',
  size = 'md',
  className = '',
  ...props
}) => {
  return (
    <span
      className={`
        ${variants[variant]} 
        ${sizes[size]} 
        inline-flex items-center rounded-full font-medium
        ${className}
      `}
      {...props}
    >
      {children}
    </span>
  );
};

export default Badge;