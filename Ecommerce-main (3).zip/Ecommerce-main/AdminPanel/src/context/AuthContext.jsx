import axios from "axios";
import { createContext, useState, useEffect } from "react";
import { toast } from "react-toastify";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    // Check if user is logged in on component mount
    const storedUser = localStorage.getItem("adminUser");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
    setIsLoading(false);
  }, []);

  const login = async (email, password) => {
    setIsLoading(true);
    try {
      const response = await fetch("http://localhost:5000/admin");
      const adminData = await response.json();

      if (email === adminData.email && password === adminData.password) {
        const adminDetails = {
          email: adminData.email,
          password: adminData.password,
        };
        const response = await axios.get(`http://localhost:5000/tokens`);
        const token = response.data.token;

        const loginResponse = await axios.post(
          `http://localhost:3000/api/login`,
          adminDetails,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        console.log(loginResponse);

        const userData = {
          email: adminData.email,
          FirstName: adminData.FirstName,
          LastName: adminData.LastName,
          token: token,
        };

        console.log("Login response:", loginResponse.data);

        sessionStorage.setItem("adminUser", JSON.stringify(userData));
        setUser(userData);
        setIsAuthenticated(true);
        toast.success("Login successful");
        return true;
      } else {
        toast.error("Invalid credentials");
        return false;
      }
    } catch (error) {
      console.error("Login error:", error);
      toast.error("Login failed. Please try again.");
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem("adminUser");
    setUser(null);
    setIsAuthenticated(false);
    toast.info("Logged out successfully");
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, isLoading, user, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
};
