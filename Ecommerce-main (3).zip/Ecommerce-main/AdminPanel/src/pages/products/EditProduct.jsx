import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Save, AlertTriangle } from "lucide-react";
import Card from "../../components/ui/Card";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";
import Spinner from "../../components/ui/Spinner";
import { toast } from "react-toastify";
import axios from "axios";

const EditProduct = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    category: "",
    stock: "",
    image: "",
  });

  const [errors, setErrors] = useState({});
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch product data
        const apiURL = VITE_APP_API_URL || "";
        const productResponse = await axios.get(
          `${apiURL}/getAllProducts/${id}`
        );
        if (!productResponse.ok) {
          throw new Error("Product not found");
        }
        const productData = await productResponse.json();

        // Format the data for the form
        setFormData({
          name: productData.name,
          description: productData.description,
          price: productData.price.toString(),
          category: productData.category,
          stock: productData.stock.toString(),
          image: productData.image,
        });

        // Fetch categories
        const categoriesResponse = await fetch(
          "http://localhost:5000/categories"
        );
        const categoriesData = await categoriesResponse.json();
        setCategories(categoriesData);
      } catch (error) {
        console.error("Error fetching product data:", error);
        toast.error("Failed to load product data");
        navigate("/products");
      } finally {
        setInitialLoading(false);
      }
    };

    fetchData();
  }, [id, navigate]);

  const handleChange = (e) => {
    const { name, value } = e.target;

    // For number fields, ensure valid numeric input
    if (name === "price" || name === "stock") {
      if (value === "" || /^\d*\.?\d*$/.test(value)) {
        setFormData({
          ...formData,
          [name]: value,
        });
      }
      return;
    }

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "Product name is required";
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required";
    }

    if (!formData.price) {
      newErrors.price = "Price is required";
    } else if (isNaN(formData.price) || Number(formData.price) <= 0) {
      newErrors.price = "Price must be a positive number";
    }

    if (!formData.category) {
      newErrors.category = "Category is required";
    }

    if (!formData.stock) {
      newErrors.stock = "Stock quantity is required";
    } else if (
      isNaN(formData.stock) ||
      Number(formData.stock) < 0 ||
      !Number.isInteger(Number(formData.stock))
    ) {
      newErrors.stock = "Stock must be a non-negative integer";
    }

    if (!formData.image.trim()) {
      newErrors.image = "Image URL is required";
    } else if (!isValidImageUrl(formData.image)) {
      newErrors.image = "Please enter a valid image URL";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const isValidImageUrl = (url) => {
    // Simple URL validation, could be enhanced
    return (
      url.match(/\.(jpeg|jpg|gif|png|webp)$/) !== null ||
      url.includes("images.pexels.com")
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setLoading(true);

    try {
      // Fetch the current product to preserve fields we don't edit
      const productResponse = await fetch(
        `http://localhost:5000/products/${id}`
      );
      const currentProduct = await productResponse.json();

      // Prepare the updated product data
      const updatedProduct = {
        ...currentProduct,
        name: formData.name,
        description: formData.description,
        price: Number(formData.price),
        category: formData.category,
        stock: Number(formData.stock),
        image: formData.image,
      };

      // Update the product
      const response = await fetch(`http://localhost:5000/products/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedProduct),
      });

      if (!response.ok) {
        throw new Error("Failed to update product");
      }

      toast.success("Product updated successfully");
      navigate(`/products/${id}`);
    } catch (error) {
      console.error("Error updating product:", error);
      toast.error("Failed to update product. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <div className="h-96 flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with back button */}
      <div className="flex items-center space-x-3">
        <button
          onClick={() => navigate(`/products/${id}`)}
          className="p-2 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold text-slate-800">Edit Product</h1>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Product Image */}
          <Card title="Product Image" className="lg:col-span-1">
            <div className="space-y-4">
              <Input
                label="Image URL"
                id="image"
                name="image"
                placeholder="https://example.com/image.jpg"
                value={formData.image}
                onChange={handleChange}
                error={errors.image}
                required
              />

              {formData.image && !errors.image ? (
                <div className="aspect-square w-full rounded-md overflow-hidden border border-slate-200">
                  <img
                    src={formData.image}
                    alt="Product preview"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.target.onerror = null;
                      setErrors((prev) => ({
                        ...prev,
                        image: "Invalid image URL or image cannot be loaded",
                      }));
                    }}
                  />
                </div>
              ) : (
                <div className="aspect-square w-full rounded-md border border-dashed border-slate-300 flex items-center justify-center bg-slate-50">
                  <div className="text-center p-4">
                    <AlertTriangle
                      size={24}
                      className="mx-auto text-slate-400"
                    />
                    <p className="mt-2 text-sm text-slate-500">
                      Enter a valid image URL to see a preview
                    </p>
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* Product Details */}
          <Card title="Product Information" className="lg:col-span-2">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <Input
                  label="Product Name"
                  id="name"
                  name="name"
                  placeholder="Enter product name"
                  value={formData.name}
                  onChange={handleChange}
                  error={errors.name}
                  required
                />
              </div>

              <div className="md:col-span-2">
                <div className="mb-4">
                  <label
                    htmlFor="description"
                    className="block text-sm font-medium text-slate-700 mb-1"
                  >
                    Description <span className="text-red-600">*</span>
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    rows={4}
                    placeholder="Enter product description"
                    value={formData.description}
                    onChange={handleChange}
                    className={`
                      w-full px-3 py-2 rounded-md border 
                      ${
                        errors.description
                          ? "border-red-500"
                          : "border-slate-300"
                      } 
                      focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                    `}
                    required
                  ></textarea>
                  {errors.description && (
                    <p className="mt-1 text-sm text-red-600">
                      {errors.description}
                    </p>
                  )}
                </div>
              </div>

              <Input
                label="Price ($)"
                id="price"
                name="price"
                type="text"
                placeholder="0.00"
                value={formData.price}
                onChange={handleChange}
                error={errors.price}
                required
              />

              <div className="mb-4">
                <label
                  htmlFor="category"
                  className="block text-sm font-medium text-slate-700 mb-1"
                >
                  Category <span className="text-red-600">*</span>
                </label>
                <select
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleChange}
                  className={`
                    w-full px-3 py-2 rounded-md border 
                    ${errors.category ? "border-red-500" : "border-slate-300"} 
                    focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                  `}
                  required
                >
                  <option value="">Select a category</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.name}>
                      {category.name}
                    </option>
                  ))}
                </select>
                {errors.category && (
                  <p className="mt-1 text-sm text-red-600">{errors.category}</p>
                )}
              </div>

              <Input
                label="Stock Quantity"
                id="stock"
                name="stock"
                type="text"
                placeholder="0"
                value={formData.stock}
                onChange={handleChange}
                error={errors.stock}
                required
              />
            </div>

            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <Button
                type="button"
                variant="secondary"
                onClick={() => navigate(`/products/${id}`)}
                fullWidth
              >
                Cancel
              </Button>

              <Button
                type="submit"
                variant="primary"
                isLoading={loading}
                icon={<Save size={16} />}
                fullWidth
              >
                Update Product
              </Button>
            </div>
          </Card>
        </div>
      </form>
    </div>
  );
};

export default EditProduct;
