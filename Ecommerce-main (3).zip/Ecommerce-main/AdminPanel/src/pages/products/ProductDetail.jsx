import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Edit, 
  Clock, 
  Package, 
  Tag,
  Truck,
  AlertTriangle
} from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import { toast } from 'react-toastify';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await fetch(`http://localhost:5000/products/${id}`);
        if (!response.ok) {
          throw new Error('Product not found');
        }
        const data = await response.json();
        setProduct(data);
      } catch (error) {
        console.error('Error fetching product:', error);
        toast.error('Failed to load product details');
        navigate('/products');
      } finally {
        setLoading(false);
      }
    };
    
    fetchProduct();
  }, [id, navigate]);
  
  // Function to determine stock status and badge
  const getStockStatus = (stock) => {
    if (stock <= 0) {
      return { 
        label: 'Out of stock', 
        variant: 'danger',
        icon: <AlertTriangle size={16} className="mr-1" />
      };
    } else if (stock < 20) {
      return { 
        label: 'Low stock', 
        variant: 'warning',
        icon: <AlertTriangle size={16} className="mr-1" />
      };
    } else {
      return { 
        label: 'In stock', 
        variant: 'success',
        icon: <Truck size={16} className="mr-1" />
      };
    }
  };
  
  if (loading) {
    return (
      <div className="h-96 flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">Product Not Found</h2>
        <p className="text-slate-600 mb-6">The product you're looking for doesn't exist or has been removed.</p>
        <Button 
          variant="primary" 
          onClick={() => navigate('/products')}
          icon={<ArrowLeft size={16} />}
        >
          Back to Products
        </Button>
      </div>
    );
  }
  
  const stockStatus = getStockStatus(product.stock);
  const createdDate = new Date(product.createdAt).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });
  
  return (
    <div className="space-y-6">
      {/* Header with back button and edit button */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-3">
          <button
            onClick={() => navigate('/products')}
            className="p-2 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100"
          >
            <ArrowLeft size={20} />
          </button>
          <h1 className="text-2xl font-bold text-slate-800">Product Details</h1>
        </div>
        
        <Button
          variant="primary"
          onClick={() => navigate(`/products/edit/${product.id}`)}
          icon={<Edit size={16} />}
        >
          Edit Product
        </Button>
      </div>
      
      {/* Product information */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Image */}
        <Card className="lg:col-span-1">
          <div className="aspect-square w-full rounded-md overflow-hidden">
            <img 
              src={product.image} 
              alt={product.name}
              className="w-full h-full object-cover" 
            />
          </div>
          
          <div className="mt-4 space-y-3">
            <div className="flex items-center text-sm text-slate-600">
              <Clock size={16} className="mr-2" />
              <span>Added on {createdDate}</span>
            </div>
            
            <div className="flex items-center text-sm text-slate-600">
              <Package size={16} className="mr-2" />
              <span>{product.stock} units available</span>
            </div>
            
            <div className="flex items-center text-sm text-slate-600">
              <Tag size={16} className="mr-2" />
              <span>Category: {product.category}</span>
            </div>
            
            <div className="pt-2">
              <Badge 
                variant={stockStatus.variant} 
                className="flex items-center"
                size="md"
              >
                {stockStatus.icon}
                {stockStatus.label}
              </Badge>
            </div>
          </div>
        </Card>
        
        {/* Details */}
        <Card className="lg:col-span-2">
          <div className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">{product.name}</h2>
              <div className="mt-2 text-2xl font-bold text-indigo-600">
                ${product.price.toFixed(2)}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-slate-800 mb-2">Description</h3>
              <p className="text-slate-600 leading-relaxed">
                {product.description}
              </p>
            </div>
            
            <div className="border-t border-slate-200 pt-6">
              <h3 className="text-lg font-semibold text-slate-800 mb-4">Product Details</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-md">
                  <p className="text-sm font-medium text-slate-500">Product ID</p>
                  <p className="text-slate-800 font-medium">{product.id}</p>
                </div>
                
                <div className="bg-slate-50 p-4 rounded-md">
                  <p className="text-sm font-medium text-slate-500">Category</p>
                  <p className="text-slate-800 font-medium">{product.category}</p>
                </div>
                
                <div className="bg-slate-50 p-4 rounded-md">
                  <p className="text-sm font-medium text-slate-500">Stock</p>
                  <p className="text-slate-800 font-medium">{product.stock} units</p>
                </div>
                
                <div className="bg-slate-50 p-4 rounded-md">
                  <p className="text-sm font-medium text-slate-500">Date Added</p>
                  <p className="text-slate-800 font-medium">{createdDate}</p>
                </div>
              </div>
            </div>
            
            <div className="border-t border-slate-200 pt-6 flex flex-col sm:flex-row gap-3">
              <Button
                variant="danger"
                onClick={() => toast.info('Delete functionality would be implemented here')}
                fullWidth
              >
                Delete Product
              </Button>
              
              <Button
                variant="primary"
                onClick={() => navigate(`/products/edit/${product.id}`)}
                fullWidth
              >
                Edit Product
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ProductDetail;