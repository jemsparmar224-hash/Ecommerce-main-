import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  Plus,
  Search,
  Edit,
  Trash2,
  Eye,
  ArrowUpDown,
  Filter,
} from "lucide-react";
import Card from "../../components/ui/Card";
import Button from "../../components/ui/Button";
import {
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "../../components/ui/Table";
import Badge from "../../components/ui/Badge";
import Spinner from "../../components/ui/Spinner";
import { toast } from "react-toastify";
import axios from "axios";

const ProductList = () => {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [sortField, setSortField] = useState("id");
  const [sortDirection, setSortDirection] = useState("asc");

  const navigate = useNavigate();
  const imageUrl = import.meta.env.VITE_IMAGE_URL;

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch products data

        sessionStorage.getItem("token", JSON.stringify(tokens));

        // Fetch categories data
        const categoriesResponse = await fetch(
          "http://localhost:5000/categories"
        );
        const categoriesData = await categoriesResponse.json();

        setProducts(productsData);
        setCategories(categoriesData);
      } catch (error) {
        console.error("Error fetching products:", error);
        toast.error("Failed to load products. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const sortedProducts = [...products]
    .filter(
      (product) =>
        (searchTerm === "" ||
          product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          product.description
            .toLowerCase()
            .includes(searchTerm.toLowerCase())) &&
        (selectedCategory === "" || product.category === selectedCategory)
    )
    .sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];

      if (typeof aValue === "string") {
        return sortDirection === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
    });

  // Function to determine stock status and badge
  const getStockStatus = (stock) => {
    if (stock <= 0) {
      return { label: "Out of stock", variant: "danger" };
    } else if (stock < 20) {
      return { label: "Low stock", variant: "warning" };
    } else {
      return { label: "In stock", variant: "success" };
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-800">Products</h1>
        <Button
          onClick={() => navigate("/products/add")}
          icon={<Plus size={16} />}
        >
          Add Product
        </Button>
      </div>

      <Card>
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search size={18} className="text-slate-400" />
            </div>
            <input
              type="text"
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="w-full md:w-64">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Filter size={18} className="text-slate-400" />
              </div>
              <select
                className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 appearance-none bg-white"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                <option value="">All Categories</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.name}>
                    {category.name}
                  </option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <ArrowUpDown size={18} className="text-slate-400" />
              </div>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="h-60 flex items-center justify-center">
            <Spinner size="lg" />
          </div>
        ) : (
          <div className="overflow-x-auto rounded-md border border-slate-200">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell header>
                    <button
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700"
                      onClick={() => handleSort("id")}
                    >
                      <span>ID</span>
                      {sortField === "id" && (
                        <ArrowUpDown
                          size={14}
                          className={
                            sortDirection === "asc"
                              ? "transform rotate-180"
                              : ""
                          }
                        />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>Image</TableCell>
                  <TableCell header>
                    <button
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700"
                      onClick={() => handleSort("name")}
                    >
                      <span>Product Name</span>
                      {sortField === "name" && (
                        <ArrowUpDown
                          size={14}
                          className={
                            sortDirection === "asc"
                              ? "transform rotate-180"
                              : ""
                          }
                        />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>
                    <button
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700"
                      onClick={() => handleSort("price")}
                    >
                      <span>Price</span>
                      {sortField === "price" && (
                        <ArrowUpDown
                          size={14}
                          className={
                            sortDirection === "asc"
                              ? "transform rotate-180"
                              : ""
                          }
                        />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>
                    <button
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700"
                      onClick={() => handleSort("category")}
                    >
                      <span>Category</span>
                      {sortField === "category" && (
                        <ArrowUpDown
                          size={14}
                          className={
                            sortDirection === "asc"
                              ? "transform rotate-180"
                              : ""
                          }
                        />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>
                    <button
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700"
                      onClick={() => handleSort("stock")}
                    >
                      <span>Stock</span>
                      {sortField === "stock" && (
                        <ArrowUpDown
                          size={14}
                          className={
                            sortDirection === "asc"
                              ? "transform rotate-180"
                              : ""
                          }
                        />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {sortedProducts.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={7}
                      className="text-center py-8 text-slate-500"
                    >
                      No products found. Try adjusting your filters or add new
                      products.
                    </TableCell>
                  </TableRow>
                ) : (
                  sortedProducts.map((product) => {
                    console.log(product);

                    const stockStatus = getStockStatus(product.stock);
                    return (
                      <TableRow
                        key={product._id}
                        onClick={() => navigate(`/products/${product.id}`)}
                      >
                        <TableCell>#{product.id}</TableCell>
                        <TableCell>
                          <img
                            src={`${imageUrl}/${product.image}`}
                            alt={product.name}
                            className="w-12 h-12 rounded object-cover"
                          />
                        </TableCell>
                        <TableCell className="font-medium text-slate-700">
                          {product.title}
                        </TableCell>
                        <TableCell>${product.price.toFixed(2)}</TableCell>
                        <TableCell>{product.category}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <Badge variant={stockStatus.variant} size="sm">
                              {stockStatus.label}
                            </Badge>
                            <span className="ml-2 text-xs text-slate-500">
                              {product.stock} units
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/products/${product.id}`);
                              }}
                              className="p-1 text-slate-500 hover:text-indigo-600 rounded-full hover:bg-slate-100"
                              title="View details"
                            >
                              <Eye size={16} />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/updateProduct/:${product.id}`);
                              }}
                              className="p-1 text-slate-500 hover:text-amber-600 rounded-full hover:bg-slate-100"
                              title="Edit product"
                            >
                              <Edit size={16} />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                // Handle delete action
                                toast.info(
                                  "Delete functionality would be implemented here"
                                );
                              }}
                              className="p-1 text-slate-500 hover:text-red-600 rounded-full hover:bg-slate-100"
                              title="Delete product"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
};

export default ProductList;
