import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Save, AlertTriangle, UploadCloud } from "lucide-react";
import Card from "../../components/ui/Card";
import Button from "../../components/ui/Button";
import Input from "../../components/ui/Input";
import Spinner from "../../components/ui/Spinner";
import { toast } from "react-toastify";
import axios from "axios";

const AddProduct = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    price: "",
    category: "",
    stock: "",
    image: null,
  });

  const token =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY4MjJlY2I1ZTg3NWM5NTVmZmRkNmMxYiIsImVtYWlsIjoidXNlcjFAZ21haWwuY29tIiwiaWF0IjoxNzQ3MTk4NTk1LCJleHAiOjE3NDcyMDIxOTV9.3ndBjsHNn3RQNKdX-xQnfMEN-eoLA2Hl70jx5XLR6cs";
  const [errors, setErrors] = useState({});
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [categoriesLoading, setCategoriesLoading] = useState(true);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch("http://localhost:5000/categories");
        const data = await response.json();
        setCategories(data);
      } catch (error) {
        console.error("Error fetching categories:", error);
        toast.error("Failed to load categories");
      } finally {
        setCategoriesLoading(false);
      }
    };

    fetchCategories();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;

    if (name === "price" || name === "stock") {
      if (value === "" || /^\d*\.?\d*$/.test(value)) {
        setFormData({
          ...formData,
          [name]: value,
        });
      }
      return;
    }

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = "Product name is required";
    }

    if (!formData.description.trim()) {
      newErrors.description = "Description is required";
    }

    if (!formData.price) {
      newErrors.price = "Price is required";
    } else if (isNaN(formData.price) || Number(formData.price) <= 0) {
      newErrors.price = "Price must be a positive number";
    }

    if (!formData.category) {
      newErrors.category = "Category is required";
    }

    if (!formData.stock) {
      newErrors.stock = "Stock quantity is required";
    } else if (
      isNaN(formData.stock) ||
      Number(formData.stock) < 0 ||
      !Number.isInteger(Number(formData.stock))
    ) {
      newErrors.stock = "Stock must be a non-negative integer";
    }

    if (!formData.image) {
      newErrors.image = "Product image is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) return;

    setLoading(true);

    try {
      const newProduct = new FormData();
      newProduct.append("title", formData.title);
      newProduct.append("description", formData.description);
      newProduct.append("price", formData.price);
      newProduct.append("category", formData.category);
      newProduct.append("stock", formData.stock);
      newProduct.append("image", formData.image);

      const apiURL = import.meta.env.VITE_API_URL;
      const response = await axios.post(`${apiURL}/productAdd`, newProduct, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });
      console.log(response);

      toast.success("Product added successfully");
      navigate("/products");
    } catch (error) {
      console.error("Error adding product:", error);
      toast.error("Failed to add product. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, image: file });
      setErrors({ ...errors, image: "" });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <button
          onClick={() => navigate("/products")}
          className="p-2 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-2xl font-bold text-slate-800">Add New Product</h1>
      </div>

      {categoriesLoading ? (
        <div className="h-96 flex items-center justify-center">
          <Spinner size="lg" />
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card title="Product Image" className="lg:col-span-1">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Product Image <span className="text-red-600">*</span>
                  </label>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition"
                  >
                    <UploadCloud size={16} className="mr-2" />
                    Upload Image
                  </button>
                  {errors.image && (
                    <p className="mt-1 text-sm text-red-600">{errors.image}</p>
                  )}
                </div>

                {formData.image && !errors.image ? (
                  <div className="aspect-square w-full rounded-md overflow-hidden border border-slate-200">
                    <img
                      src={URL.createObjectURL(formData.image)}
                      alt="Product preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div className="aspect-square w-full rounded-md border border-dashed border-slate-300 flex items-center justify-center bg-slate-50">
                    <div className="text-center p-4">
                      <AlertTriangle
                        size={24}
                        className="mx-auto text-slate-400"
                      />
                      <p className="mt-2 text-sm text-slate-500">
                        Upload an image to see a preview
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </Card>

            <Card title="Product Information" className="lg:col-span-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <Input
                    label="Product Name"
                    id="title"
                    name="title"
                    placeholder="Enter product title"
                    value={formData.title}
                    onChange={handleChange}
                    error={errors.title}
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <div className="mb-4">
                    <label
                      htmlFor="description"
                      className="block text-sm font-medium text-slate-700 mb-1"
                    >
                      Description <span className="text-red-600">*</span>
                    </label>
                    <textarea
                      id="description"
                      name="description"
                      rows={4}
                      placeholder="Enter product description"
                      value={formData.description}
                      onChange={handleChange}
                      className={`w-full px-3 py-2 rounded-md border ${
                        errors.description
                          ? "border-red-500"
                          : "border-slate-300"
                      } focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500`}
                      required
                    ></textarea>
                    {errors.description && (
                      <p className="mt-1 text-sm text-red-600">
                        {errors.description}
                      </p>
                    )}
                  </div>
                </div>

                <Input
                  label="Price ($)"
                  id="price"
                  name="price"
                  type="text"
                  placeholder="0.00"
                  value={formData.price}
                  onChange={handleChange}
                  error={errors.price}
                  required
                />

                <div className="mb-4">
                  <label
                    htmlFor="category"
                    className="block text-sm font-medium text-slate-700 mb-1"
                  >
                    Category <span className="text-red-600">*</span>
                  </label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className={`w-full px-3 py-2 rounded-md border ${
                      errors.category ? "border-red-500" : "border-slate-300"
                    } focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500`}
                    required
                  >
                    <option value="">Select a category</option>
                    {categories.map((category) => (
                      <option key={category.id} value={category.name}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                  {errors.category && (
                    <p className="mt-1 text-sm text-red-600">
                      {errors.category}
                    </p>
                  )}
                </div>

                <Input
                  label="Stock Quantity"
                  id="stock"
                  name="stock"
                  type="text"
                  placeholder="0"
                  value={formData.stock}
                  onChange={handleChange}
                  error={errors.stock}
                  required
                />
              </div>

              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => navigate("/products")}
                  fullWidth
                >
                  Cancel
                </Button>

                <Button
                  type="submit"
                  variant="primary"
                  isLoading={loading}
                  icon={<Save size={16} />}
                  fullWidth
                >
                  Save Product
                </Button>
              </div>
            </Card>
          </div>
        </form>
      )}
    </div>
  );
};

export default AddProduct;
