import { useState, useEffect } from 'react';
import { Search, Eye, ShoppingCart, ArrowDown, ArrowUp } from 'lucide-react';
import Card from '../../components/ui/Card';
import { Table, TableHead, TableBody, TableRow, TableCell } from '../../components/ui/Table';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import { toast } from 'react-toastify';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [sortField, setSortField] = useState('id');
  const [sortDirection, setSortDirection] = useState('desc'); // Newest first
  const [selectedOrder, setSelectedOrder] = useState(null);
  
  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await fetch('http://localhost:5000/orders');
        const data = await response.json();
        setOrders(data);
      } catch (error) {
        console.error('Error fetching orders:', error);
        toast.error('Failed to load orders');
      } finally {
        setLoading(false);
      }
    };
    
    fetchOrders();
  }, []);
  
  const handleSort = (field) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc'); // Default to newest first when changing sort field
    }
  };
  
  // Filter and sort orders
  const filteredOrders = orders
    .filter(order => 
      // Filter by search term
      (searchTerm === '' || 
        order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        `#${order.id}`.includes(searchTerm)
      ) &&
      // Filter by status
      (statusFilter === '' || order.status === statusFilter)
    )
    .sort((a, b) => {
      // Sort by field
      let aValue = a[sortField];
      let bValue = b[sortField];
      
      // For date fields, convert to Date objects
      if (sortField === 'createdAt') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }
      
      // Perform the sort
      if (sortDirection === 'asc') {
        return aValue > bValue ? 1 : aValue < bValue ? -1 : 0;
      } else {
        return aValue < bValue ? 1 : aValue > bValue ? -1 : 0;
      }
    });
  
  // Get status badge variant
  const getStatusBadge = (status) => {
    switch (status) {
      case 'delivered':
        return 'success';
      case 'shipped':
        return 'primary';
      case 'processing':
        return 'warning';
      case 'cancelled':
        return 'danger';
      default:
        return 'secondary';
    }
  };
  
  // Format date
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };
  
  // Handle order selection for details view
  const handleOrderClick = (order) => {
    setSelectedOrder(order);
  };
  
  const handleOrderStatusChange = async (orderId, newStatus) => {
    try {
      // Find the order to update
      const orderToUpdate = orders.find(order => order.id === orderId);
      if (!orderToUpdate) return;
      
      // Update the order status
      const updatedOrder = {
        ...orderToUpdate,
        status: newStatus
      };
      
      // Make API request to update the order
      const response = await fetch(`http://localhost:5000/orders/${orderId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updatedOrder)
      });
      
      if (!response.ok) {
        throw new Error('Failed to update order status');
      }
      
      // Update local state
      setOrders(orders.map(order => 
        order.id === orderId ? { ...order, status: newStatus } : order
      ));
      
      // If the updated order is the selected one, update selected order state
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder({ ...selectedOrder, status: newStatus });
      }
      
      toast.success(`Order status updated to ${newStatus}`);
    } catch (error) {
      console.error('Error updating order status:', error);
      toast.error('Failed to update order status');
    }
  };
  
  const closeOrderDetails = () => {
    setSelectedOrder(null);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-800">Orders</h1>
      </div>
      
      <Card>
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search size={18} className="text-slate-400" />
            </div>
            <input
              type="text"
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Search orders by customer or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          
          <div className="w-full md:w-64">
            <select
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="">All Statuses</option>
              <option value="processing">Processing</option>
              <option value="shipped">Shipped</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
          </div>
        </div>
        
        {loading ? (
          <div className="h-60 flex items-center justify-center">
            <Spinner size="lg" />
          </div>
        ) : (
          <div className="overflow-x-auto rounded-md border border-slate-200">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell header>
                    <button 
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700" 
                      onClick={() => handleSort('id')}
                    >
                      <span>Order ID</span>
                      {sortField === 'id' && (
                        sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>
                    <button 
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700" 
                      onClick={() => handleSort('customerName')}
                    >
                      <span>Customer</span>
                      {sortField === 'customerName' && (
                        sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>
                    <button 
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700" 
                      onClick={() => handleSort('createdAt')}
                    >
                      <span>Date</span>
                      {sortField === 'createdAt' && (
                        sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>
                    <button 
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700" 
                      onClick={() => handleSort('total')}
                    >
                      <span>Total</span>
                      {sortField === 'total' && (
                        sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>
                    <button 
                      className="flex items-center space-x-1 text-xs font-medium text-slate-500 hover:text-slate-700" 
                      onClick={() => handleSort('status')}
                    >
                      <span>Status</span>
                      {sortField === 'status' && (
                        sortDirection === 'asc' ? <ArrowUp size={14} /> : <ArrowDown size={14} />
                      )}
                    </button>
                  </TableCell>
                  <TableCell header>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredOrders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-slate-500">
                      No orders found. Try adjusting your filters.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredOrders.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell>#{order.id}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium text-slate-700">{order.customerName}</p>
                          <p className="text-xs text-slate-500">{order.email}</p>
                        </div>
                      </TableCell>
                      <TableCell>{formatDate(order.createdAt)}</TableCell>
                      <TableCell className="font-medium">${order.total.toFixed(2)}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadge(order.status)}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <button
                          onClick={() => handleOrderClick(order)}
                          className="p-1 text-slate-500 hover:text-indigo-600 rounded-full hover:bg-slate-100"
                          title="View order details"
                        >
                          <Eye size={16} />
                        </button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
      
      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex min-h-screen items-center justify-center p-4 text-center sm:p-0">
            {/* Overlay */}
            <div 
              className="fixed inset-0 bg-slate-900/50 transition-opacity"
              onClick={closeOrderDetails}
            ></div>
            
            {/* Modal */}
            <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-3xl">
              <div className="absolute top-0 right-0 p-4">
                <button
                  onClick={closeOrderDetails}
                  className="text-slate-400 hover:text-slate-500"
                >
                  <span className="sr-only">Close</span>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              
              <div className="px-6 py-4 border-b border-slate-200">
                <div className="flex items-center">
                  <ShoppingCart size={20} className="text-indigo-600 mr-2" />
                  <h3 className="text-lg font-medium text-slate-800">Order #{selectedOrder.id}</h3>
                </div>
              </div>
              
              <div className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-1">Customer Information</h4>
                    <p className="font-medium text-slate-700">{selectedOrder.customerName}</p>
                    <p className="text-slate-600">{selectedOrder.email}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-1">Order Details</h4>
                    <p className="font-medium text-slate-700">Date: {formatDate(selectedOrder.createdAt)}</p>
                    <div className="flex items-center mt-1">
                      <p className="text-slate-600 mr-2">Status:</p>
                      <Badge variant={getStatusBadge(selectedOrder.status)}>
                        {selectedOrder.status.charAt(0).toUpperCase() + selectedOrder.status.slice(1)}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <h4 className="text-sm font-medium text-slate-500 mb-3">Order Items</h4>
                <div className="overflow-x-auto rounded-md border border-slate-200 mb-6">
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell header>Product</TableCell>
                        <TableCell header>Price</TableCell>
                        <TableCell header>Quantity</TableCell>
                        <TableCell header>Subtotal</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {selectedOrder.products.map((item, index) => (
                        <TableRow key={index}>
                          <TableCell>Product #{item.productId}</TableCell>
                          <TableCell>${item.price.toFixed(2)}</TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell>${(item.price * item.quantity).toFixed(2)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                
                <div className="flex justify-between items-center border-t border-slate-200 pt-4">
                  <div>
                    <h4 className="text-sm font-medium text-slate-500 mb-1">Update Status</h4>
                    <select
                      className="w-full sm:w-auto px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                      value={selectedOrder.status}
                      onChange={(e) => handleOrderStatusChange(selectedOrder.id, e.target.value)}
                    >
                      <option value="processing">Processing</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-sm text-slate-500">Total</p>
                    <p className="text-xl font-bold text-slate-800">${selectedOrder.total.toFixed(2)}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Orders;