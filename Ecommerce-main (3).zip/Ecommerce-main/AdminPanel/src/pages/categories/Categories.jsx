import { useState, useEffect } from 'react';
import { PlusCircle, Edit, Trash2, Save, X } from 'lucide-react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { Table, TableHead, TableBody, TableRow, TableCell } from '../../components/ui/Table';
import Input from '../../components/ui/Input';
import Spinner from '../../components/ui/Spinner';
import { toast } from 'react-toastify';

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    description: ''
  });
  
  const [errors, setErrors] = useState({});
  
  useEffect(() => {
    fetchCategories();
  }, []);
  
  const fetchCategories = async () => {
    try {
      const response = await fetch('http://localhost:5000/categories');
      const data = await response.json();
      setCategories(data);
    } catch (error) {
      console.error('Error fetching categories:', error);
      toast.error('Failed to load categories');
    } finally {
      setLoading(false);
    }
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Category name is required';
    }
    
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleAddNew = () => {
    setFormData({
      name: '',
      description: ''
    });
    setErrors({});
    setShowAddForm(true);
  };
  
  const handleEdit = (category) => {
    setFormData({
      name: category.name,
      description: category.description
    });
    setErrors({});
    setEditingId(category.id);
  };
  
  const handleCancel = () => {
    setShowAddForm(false);
    setEditingId(null);
    setFormData({
      name: '',
      description: ''
    });
    setErrors({});
  };
  
  const handleAddSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      setLoading(true);
      
      // Get the highest ID to generate the next ID
      const nextId = Math.max(0, ...categories.map(c => c.id)) + 1;
      
      // Prepare the new category data
      const newCategory = {
        id: nextId,
        name: formData.name,
        description: formData.description
      };
      
      // Save the new category
      const response = await fetch('http://localhost:5000/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newCategory)
      });
      
      if (!response.ok) {
        throw new Error('Failed to add category');
      }
      
      // Refresh categories list
      await fetchCategories();
      
      // Reset form
      setShowAddForm(false);
      setFormData({
        name: '',
        description: ''
      });
      
      toast.success('Category added successfully');
    } catch (error) {
      console.error('Error adding category:', error);
      toast.error('Failed to add category. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      setLoading(true);
      
      // Find the category to update
      const categoryToUpdate = categories.find(c => c.id === editingId);
      if (!categoryToUpdate) throw new Error('Category not found');
      
      // Prepare the updated category data
      const updatedCategory = {
        ...categoryToUpdate,
        name: formData.name,
        description: formData.description
      };
      
      // Update the category
      const response = await fetch(`http://localhost:5000/categories/${editingId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(updatedCategory)
      });
      
      if (!response.ok) {
        throw new Error('Failed to update category');
      }
      
      // Refresh categories list
      await fetchCategories();
      
      // Reset form
      setEditingId(null);
      setFormData({
        name: '',
        description: ''
      });
      
      toast.success('Category updated successfully');
    } catch (error) {
      console.error('Error updating category:', error);
      toast.error('Failed to update category. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleDelete = async (id) => {
    // Check if any products use this category
    try {
      const response = await fetch('http://localhost:5000/products');
      const products = await response.json();
      
      const categoryName = categories.find(c => c.id === id)?.name;
      
      if (products.some(product => product.category === categoryName)) {
        toast.error('Cannot delete category that has products. Remove or reassign products first.');
        return;
      }
      
      if (window.confirm('Are you sure you want to delete this category?')) {
        setLoading(true);
        
        const response = await fetch(`http://localhost:5000/categories/${id}`, {
          method: 'DELETE'
        });
        
        if (!response.ok) {
          throw new Error('Failed to delete category');
        }
        
        // Refresh categories list
        await fetchCategories();
        
        toast.success('Category deleted successfully');
      }
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error('Failed to delete category. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-800">Categories</h1>
        <Button
          onClick={handleAddNew}
          disabled={showAddForm}
          icon={<PlusCircle size={16} />}
        >
          Add Category
        </Button>
      </div>
      
      {showAddForm && (
        <Card title="Add New Category">
          <form onSubmit={handleAddSubmit}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Category Name"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                error={errors.name}
                required
              />
              
              <Input
                label="Description"
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                error={errors.description}
                required
              />
            </div>
            
            <div className="mt-6 flex justify-end space-x-3">
              <Button
                type="button"
                variant="secondary"
                onClick={handleCancel}
                icon={<X size={16} />}
              >
                Cancel
              </Button>
              
              <Button
                type="submit"
                isLoading={loading}
                icon={<Save size={16} />}
              >
                Save Category
              </Button>
            </div>
          </form>
        </Card>
      )}
      
      <Card>
        {loading && !showAddForm && !editingId ? (
          <div className="h-60 flex items-center justify-center">
            <Spinner size="lg" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell header>ID</TableCell>
                  <TableCell header>Name</TableCell>
                  <TableCell header>Description</TableCell>
                  <TableCell header>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {categories.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-slate-500">
                      No categories found. Add your first category.
                    </TableCell>
                  </TableRow>
                ) : (
                  categories.map((category) => (
                    <TableRow key={category.id}>
                      {editingId === category.id ? (
                        <TableCell colSpan={4}>
                          <form onSubmit={handleEditSubmit} className="py-2">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                              <Input
                                label="Category Name"
                                id="edit-name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                error={errors.name}
                                required
                              />
                              
                              <Input
                                label="Description"
                                id="edit-description"
                                name="description"
                                value={formData.description}
                                onChange={handleInputChange}
                                error={errors.description}
                                required
                              />
                              
                              <div className="flex items-end space-x-2 mb-4">
                                <Button
                                  type="submit"
                                  variant="success"
                                  size="sm"
                                  isLoading={loading}
                                  icon={<Save size={14} />}
                                >
                                  Save
                                </Button>
                                
                                <Button
                                  type="button"
                                  variant="secondary"
                                  size="sm"
                                  onClick={handleCancel}
                                  icon={<X size={14} />}
                                >
                                  Cancel
                                </Button>
                              </div>
                            </div>
                          </form>
                        </TableCell>
                      ) : (
                        <>
                          <TableCell>#{category.id}</TableCell>
                          <TableCell className="font-medium">{category.name}</TableCell>
                          <TableCell>{category.description}</TableCell>
                          <TableCell>
                            <div className="flex items-center space-x-2">
                              <button 
                                onClick={() => handleEdit(category)}
                                className="p-1 text-slate-500 hover:text-amber-600 rounded-full hover:bg-slate-100" 
                                title="Edit category"
                              >
                                <Edit size={16} />
                              </button>
                              <button 
                                onClick={() => handleDelete(category.id)}
                                className="p-1 text-slate-500 hover:text-red-600 rounded-full hover:bg-slate-100" 
                                title="Delete category"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </TableCell>
                        </>
                      )}
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
};

export default Categories;