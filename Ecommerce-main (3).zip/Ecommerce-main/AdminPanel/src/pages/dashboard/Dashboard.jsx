import { useState, useEffect } from 'react';
import { 
  ShoppingCart, 
  DollarSign, 
  Package, 
  Users,
  TrendingUp,
  Truck,
  CheckCircle
} from 'lucide-react';
import Card from '../../components/ui/Card';
import { Table, TableHead, TableBody, TableRow, TableCell } from '../../components/ui/Table';
import Badge from '../../components/ui/Badge';
import Spinner from '../../components/ui/Spinner';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
} from 'chart.js';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

const Dashboard = () => {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch orders data
        const ordersResponse = await fetch('http://localhost:5000/orders');
        const ordersData = await ordersResponse.json();
        
        // Fetch products data
        const productsResponse = await fetch('http://localhost:5000/products');
        const productsData = await productsResponse.json();
        
        setOrders(ordersData);
        setProducts(productsData);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  // Calculate summary data
  const totalSales = orders.reduce((total, order) => total + order.total, 0);
  const totalProducts = products.length;
  const totalOrders = orders.length;
  const lowStockProducts = products.filter(product => product.stock < 20).length;
  
  // Status counts for orders
  const statusCounts = orders.reduce((acc, order) => {
    acc[order.status] = (acc[order.status] || 0) + 1;
    return acc;
  }, {});
  
  // Data for sales chart
  const salesChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        label: 'Sales',
        data: [4200, 3800, 5100, 4800, 6200, 7500],
        backgroundColor: 'rgba(99, 102, 241, 0.6)',
        borderColor: 'rgb(99, 102, 241)',
        borderWidth: 1
      }
    ]
  };
  
  // Data for category distribution chart
  const categoryChartData = {
    labels: ['Electronics', 'Furniture', 'Home & Kitchen', 'Clothing'],
    datasets: [
      {
        data: [45, 25, 20, 10],
        backgroundColor: [
          'rgba(99, 102, 241, 0.8)',
          'rgba(5, 150, 105, 0.8)',
          'rgba(245, 158, 11, 0.8)',
          'rgba(239, 68, 68, 0.8)'
        ],
        borderColor: [
          'rgb(99, 102, 241)',
          'rgb(5, 150, 105)',
          'rgb(245, 158, 11)',
          'rgb(239, 68, 68)'
        ],
        borderWidth: 1
      }
    ]
  };
  
  // Get status badge variant
  const getStatusBadge = (status) => {
    switch (status) {
      case 'delivered':
        return { variant: 'success', icon: <CheckCircle size={14} /> };
      case 'shipped':
        return { variant: 'primary', icon: <Truck size={14} /> };
      case 'processing':
        return { variant: 'warning', icon: <TrendingUp size={14} /> };
      default:
        return { variant: 'secondary', icon: null };
    }
  };
  
  if (loading) {
    return (
      <div className="h-96 flex items-center justify-center">
        <Spinner size="lg" />
      </div>
    );
  }
  
  return (
    <div className="space-y-6">
      {/* Stats overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-indigo-600 to-indigo-700 text-white">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20">
              <DollarSign size={24} />
            </div>
            <div className="ml-4">
              <p className="text-white/80 text-sm font-medium">Total Sales</p>
              <h3 className="text-2xl font-bold mt-1">${totalSales.toFixed(2)}</h3>
            </div>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-br from-emerald-600 to-emerald-700 text-white">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20">
              <ShoppingCart size={24} />
            </div>
            <div className="ml-4">
              <p className="text-white/80 text-sm font-medium">Total Orders</p>
              <h3 className="text-2xl font-bold mt-1">{totalOrders}</h3>
            </div>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-br from-amber-500 to-amber-600 text-white">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20">
              <Package size={24} />
            </div>
            <div className="ml-4">
              <p className="text-white/80 text-sm font-medium">Total Products</p>
              <h3 className="text-2xl font-bold mt-1">{totalProducts}</h3>
            </div>
          </div>
        </Card>
        
        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-white/20">
              <Users size={24} />
            </div>
            <div className="ml-4">
              <p className="text-white/80 text-sm font-medium">Low Stock</p>
              <h3 className="text-2xl font-bold mt-1">{lowStockProducts}</h3>
            </div>
          </div>
        </Card>
      </div>
      
      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card title="Sales Overview" className="lg:col-span-2">
          <div className="h-72">
            <Bar 
              data={salesChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'top',
                  },
                  title: {
                    display: false,
                  },
                },
              }}
            />
          </div>
        </Card>
        
        <Card title="Category Distribution">
          <div className="h-72 flex items-center justify-center">
            <Doughnut 
              data={categoryChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom',
                  },
                },
              }}
            />
          </div>
        </Card>
      </div>
      
      {/* Recent orders */}
      <Card title="Recent Orders" subtitle="Latest customer orders">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell header>Order ID</TableCell>
              <TableCell header>Customer</TableCell>
              <TableCell header>Date</TableCell>
              <TableCell header>Amount</TableCell>
              <TableCell header>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {orders.slice(0, 5).map((order) => {
              const { variant, icon } = getStatusBadge(order.status);
              return (
                <TableRow key={order.id}>
                  <TableCell>#{order.id}</TableCell>
                  <TableCell>{order.customerName}</TableCell>
                  <TableCell>
                    {new Date(order.createdAt).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric', 
                      year: 'numeric' 
                    })}
                  </TableCell>
                  <TableCell>${order.total.toFixed(2)}</TableCell>
                  <TableCell>
                    <Badge variant={variant} className="flex items-center gap-1">
                      {icon}
                      {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                    </Badge>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>
      
      {/* Low stock products */}
      <Card title="Low Stock Products" subtitle="Products that need attention">
        <Table>
          <TableHead>
            <TableRow>
              <TableCell header>Product</TableCell>
              <TableCell header>Price</TableCell>
              <TableCell header>Category</TableCell>
              <TableCell header>Stock</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {products.filter(p => p.stock < 20).slice(0, 5).map((product) => (
              <TableRow key={product.id}>
                <TableCell className="flex items-center gap-3">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-10 h-10 rounded object-cover" 
                  />
                  <span className="font-medium truncate max-w-[200px]">{product.name}</span>
                </TableCell>
                <TableCell>${product.price.toFixed(2)}</TableCell>
                <TableCell>{product.category}</TableCell>
                <TableCell>
                  <Badge variant="danger" size="sm">{product.stock} left</Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
};

export default Dashboard;