import { useState, useEffect } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { 
  Store, 
  LayoutDashboard, 
  ShoppingCart, 
  Tags, 
  LogOut, 
  Menu, 
  X,
  ChevronDown,
  User
} from 'lucide-react';

const MainLayout = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  
  useEffect(() => {
    // Close sidebar on mobile when route changes
    setIsSidebarOpen(false);
  }, [location.pathname]);
  
  const navigation = [
    { 
      name: 'Dashboard', 
      path: '/', 
      icon: <LayoutDashboard size={20} /> 
    },
    { 
      name: 'Products', 
      path: '/products', 
      icon: <Store size={20} /> 
    },
    { 
      name: 'Orders', 
      path: '/orders', 
      icon: <ShoppingCart size={20} /> 
    },
    { 
      name: 'Categories', 
      path: '/categories', 
      icon: <Tags size={20} /> 
    },
  ];
  
  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  // Function to get page title based on current path
  const getPageTitle = () => {
    const route = navigation.find(item => 
      item.path === location.pathname || 
      (item.path !== '/' && location.pathname.startsWith(item.path))
    );
    
    if (route) return route.name;
    
    if (location.pathname.includes('/products/add')) return 'Add Product';
    if (location.pathname.includes('/products/edit')) return 'Edit Product';
    if (location.pathname.includes('/products/')) return 'Product Details';
    
    return 'Dashboard';
  };
  
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile sidebar toggle */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-30 bg-white border-b border-slate-200 px-4 h-16 flex items-center">
        <button 
          onClick={toggleSidebar}
          className="text-slate-600 hover:text-indigo-600 transition-colors"
        >
          <Menu size={24} />
        </button>
        <h1 className="ml-4 text-lg font-semibold text-slate-800">E-commerce Admin</h1>
      </div>
      
      {/* Overlay */}
      {isSidebarOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-slate-800/50 z-20"
          onClick={() => setIsSidebarOpen(false)}
        ></div>
      )}
      
      {/* Sidebar */}
      <aside 
        className={`
          fixed top-0 left-0 h-full w-64 bg-white border-r border-slate-200 z-30
          transform transition-transform duration-300 ease-in-out
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} 
          lg:translate-x-0
        `}
      >
        <div className="p-5 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Store size={24} className="text-indigo-600" />
            <h1 className="text-lg font-semibold text-slate-800">E-commerce Admin</h1>
          </div>
          <button 
            onClick={toggleSidebar}
            className="lg:hidden text-slate-600 hover:text-slate-900"
          >
            <X size={20} />
          </button>
        </div>
        
        <nav className="py-6">
          <ul className="space-y-1">
            {navigation.map((item) => (
              <li key={item.name}>
                <button
                  onClick={() => navigate(item.path)}
                  className={`
                    w-full flex items-center px-5 py-3 text-base font-medium rounded-none
                    ${location.pathname === item.path || 
                      (item.path !== '/' && location.pathname.startsWith(item.path))
                        ? 'text-indigo-600 bg-indigo-50 border-r-4 border-indigo-600'
                        : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'}
                    transition-colors duration-200
                  `}
                >
                  <span className="mr-3">{item.icon}</span>
                  {item.name}
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
      
      {/* Main content */}
      <main className={`lg:ml-64 pt-16 lg:pt-0 transition-all duration-300`}>
        {/* Header */}
        <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 sticky top-0 z-10">
          <h1 className="text-xl font-semibold text-slate-800 hidden lg:block">
            {getPageTitle()}
          </h1>
          
          {/* User dropdown */}
          <div className="relative ml-auto">
            <button
              onClick={toggleDropdown}
              className="flex items-center space-x-2 text-slate-600 hover:text-slate-900 focus:outline-none"
            >
              <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center">
                <User size={18} />
              </div>
              <span className="font-medium hidden sm:block">{user?.username || 'Admin'}</span>
              <ChevronDown size={16} />
            </button>
            
            {dropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-10"
                  onClick={() => setDropdownOpen(false)}
                ></div>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg py-1 z-20 border border-slate-200">
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-100 flex items-center"
                  >
                    <LogOut size={16} className="mr-2" />
                    Sign out
                  </button>
                </div>
              </>
            )}
          </div>
        </header>
        
        {/* Page content */}
        <div className="p-6">
          <Outlet />
        </div>
      </main>
    </div>
  );
};

export default MainLayout;